
  # Design Aalia Systems Website

  This is a code bundle for Design Aalia Systems Website. The original project is available at https://www.figma.com/design/IgbxPAI7FMzhfwJYKt5pCb/Design-Aalia-Systems-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  