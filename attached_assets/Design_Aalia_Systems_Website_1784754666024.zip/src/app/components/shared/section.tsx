import { cn } from "../ui/utils";
import type { ReactNode } from "react";
import { Kicker } from "./glass";

/** Consistent page section wrapper with responsive padding + max width. */
export function Section({
  children,
  className,
  wide = false,
}: {
  children: ReactNode;
  className?: string;
  wide?: boolean;
}) {
  return (
    <section className={cn("px-5 py-14 sm:px-8 sm:py-20", className)}>
      <div className={cn("mx-auto w-full", wide ? "max-w-7xl" : "max-w-6xl")}>
        {children}
      </div>
    </section>
  );
}

export function SectionHeading({
  kicker,
  title,
  support,
  align = "left",
  className,
}: {
  kicker?: string;
  title: ReactNode;
  support?: ReactNode;
  align?: "left" | "center";
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex flex-col gap-3",
        align === "center" && "items-center text-center",
        className,
      )}
    >
      {kicker && <Kicker>{kicker}</Kicker>}
      <h2 className="max-w-2xl text-[1.9rem] leading-[1.15] text-charcoal">
        {title}
      </h2>
      {support && (
        <p className="max-w-xl text-[1.02rem] leading-relaxed text-muted-foreground">
          {support}
        </p>
      )}
    </div>
  );
}
