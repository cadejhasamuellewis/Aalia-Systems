import type { ReactNode } from "react";
import { Kicker } from "./glass";

/** Standard interior-page hero for public pages. */
export function PageHero({
  kicker,
  title,
  support,
  children,
}: {
  kicker: string;
  title: ReactNode;
  support?: ReactNode;
  children?: ReactNode;
}) {
  return (
    <section className="px-5 pb-6 pt-14 sm:px-8 sm:pt-20">
      <div className="mx-auto max-w-6xl">
        <Kicker>{kicker}</Kicker>
        <h1 className="mt-4 max-w-3xl text-[2.2rem] leading-[1.1] text-charcoal sm:text-[2.8rem]">
          {title}
        </h1>
        {support && (
          <p className="mt-4 max-w-2xl text-[1.05rem] leading-relaxed text-muted-foreground">
            {support}
          </p>
        )}
        {children && <div className="mt-6">{children}</div>}
      </div>
    </section>
  );
}
