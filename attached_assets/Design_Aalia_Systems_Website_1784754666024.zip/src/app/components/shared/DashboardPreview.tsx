import { Glass } from "./glass";
import { StatusPill } from "./status";
import { heroDashboard } from "../../data/mock";
import { TrendingUp, ShieldCheck, Globe, CheckCircle2 } from "lucide-react";

/** The frosted "Sample dashboard preview" used on Home + Client Platform pages. */
export function DashboardPreview() {
  return (
    <Glass className="w-full max-w-md p-5 sm:p-6" tint="cream">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-aqua text-cream">
            <ShieldCheck className="h-4 w-4" />
          </span>
          <div className="leading-tight">
            <div className="text-[0.9rem] text-charcoal">Marigold &amp; Co.</div>
            <div className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">
              Sample dashboard preview
            </div>
          </div>
        </div>
        <StatusPill tone="aqua">Live</StatusPill>
      </div>

      <div className="mt-5 space-y-1">
        {heroDashboard.map((row) => (
          <div
            key={row.label}
            className="flex items-center justify-between border-b border-border/50 py-2 last:border-0"
          >
            <span className="text-[0.86rem] text-slate">{row.label}</span>
            <StatusPill tone={row.tone}>{row.value}</StatusPill>
          </div>
        ))}
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2">
        {[
          { icon: Globe, k: "Uptime", v: "99.9%" },
          { icon: TrendingUp, k: "Visitors", v: "1,320" },
          { icon: CheckCircle2, k: "Requests", v: "4 open" },
        ].map((s) => (
          <div key={s.k} className="rounded-xl border border-white/60 bg-white/55 p-2.5">
            <s.icon className="h-3.5 w-3.5 text-copper" />
            <div className="mt-1.5 font-mono text-[0.95rem] text-charcoal">{s.v}</div>
            <div className="text-[0.66rem] text-muted-foreground">{s.k}</div>
          </div>
        ))}
      </div>
    </Glass>
  );
}
