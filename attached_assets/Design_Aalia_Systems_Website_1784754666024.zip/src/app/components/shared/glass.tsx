import { cn } from "../ui/utils";
import type { ReactNode, HTMLAttributes } from "react";

/** Frosted glass panel — the core surface of the Aalia system look. */
export function Glass({
  className,
  children,
  tint = "default",
  ...props
}: HTMLAttributes<HTMLDivElement> & {
  tint?: "default" | "aqua" | "ice" | "cream";
}) {
  const tints = {
    default: "bg-white/55",
    aqua: "bg-aqua/10",
    ice: "bg-ice/45",
    cream: "bg-cream/70",
  };
  return (
    <div
      className={cn(
        "rounded-[var(--radius)] border border-white/50 backdrop-blur-xl",
        "shadow-[0_1px_0_rgba(255,255,255,0.6)_inset,0_12px_40px_-16px_rgba(22,86,92,0.22)]",
        tints[tint],
        className,
      )}
      {...props}
    >
      {children}
    </div>
  );
}

/** Small uppercase mono label used above headings. */
export function Kicker({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 font-mono uppercase tracking-[0.18em] text-copper",
        "text-[0.68rem]",
        className,
      )}
    >
      <span className="h-px w-6 bg-copper/60" />
      {children}
    </span>
  );
}

/** A pill chip for hero proof points / tags. */
export function Chip({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-white/60 bg-white/50 px-3 py-1.5 text-slate backdrop-blur-md",
        "text-[0.8rem]",
        className,
      )}
    >
      {children}
    </span>
  );
}
