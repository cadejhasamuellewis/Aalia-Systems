import { cn } from "../ui/utils";
import type { ReactNode } from "react";
import { Check, Clock, AlertTriangle, Minus } from "lucide-react";

type Tone = "ok" | "info" | "warn" | "muted" | "aqua";

const toneStyles: Record<Tone, string> = {
  ok: "bg-[#e2efe6] text-[#2f6d46] border-[#bfe0cc]",
  info: "bg-ice/60 text-[#17454a] border-ice-deep",
  warn: "bg-[#f6ecd7] text-[#8a6420] border-[#e6d3a3]",
  muted: "bg-muted/70 text-muted-foreground border-border",
  aqua: "bg-aqua/12 text-aqua border-aqua/25",
};

/** Live status pill for dashboards (Online, Active, Connected...). */
export function StatusPill({
  children,
  tone = "ok",
  dot = true,
  className,
}: {
  children: ReactNode;
  tone?: Tone;
  dot?: boolean;
  className?: string;
}) {
  const dotColor: Record<Tone, string> = {
    ok: "bg-[#3f9c66]",
    info: "bg-aqua-bright",
    warn: "bg-[#c79126]",
    muted: "bg-muted-foreground",
    aqua: "bg-aqua",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 font-mono text-[0.72rem] tracking-wide",
        toneStyles[tone],
        className,
      )}
    >
      {dot && (
        <span className={cn("h-1.5 w-1.5 rounded-full", dotColor[tone])} />
      )}
      {children}
    </span>
  );
}

/** Build-handoff feature status label. */
type FeatureState =
  | "Live in MVP"
  | "Planned"
  | "Prototype"
  | "Concept demonstration"
  | "Sample data"
  | "Requires integration"
  | "Requires legal review"
  | "Requires payment processor setup";

const featureTone: Record<FeatureState, Tone> = {
  "Live in MVP": "ok",
  Planned: "info",
  Prototype: "aqua",
  "Concept demonstration": "muted",
  "Sample data": "warn",
  "Requires integration": "warn",
  "Requires legal review": "warn",
  "Requires payment processor setup": "warn",
};

export function FeatureLabel({
  state,
  className,
}: {
  state: FeatureState;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md border px-1.5 py-0.5 font-mono text-[0.62rem] uppercase tracking-[0.1em]",
        toneStyles[featureTone[state]],
        className,
      )}
    >
      {state}
    </span>
  );
}

/** Row used in dashboard status cards: label + value + pill. */
export function StatusRow({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3 border-b border-border/60 py-2.5 last:border-0">
      <span className="text-[0.85rem] text-muted-foreground">{label}</span>
      {children}
    </div>
  );
}

export const statusIcon = { Check, Clock, AlertTriangle, Minus };
