import { Link, NavLink, Outlet, useLocation } from "react-router";
import { useEffect, useState } from "react";
import { Menu, X, ArrowUpRight } from "lucide-react";
import { Button } from "../ui/button";
import { publicNav } from "../../data/mock";
import { cn } from "../ui/utils";

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-3 group">
      {/* Geometric mark — small aqua square rotated 45° */}
      <span
        className="h-3 w-3 shrink-0 rotate-45 bg-aqua block"
        aria-hidden="true"
      />
      <span className="flex flex-col leading-none">
        <span className="font-display text-[1.1rem] tracking-[-0.01em] text-charcoal">
          Aalia Systems
        </span>
        <span className="font-mono text-[0.58rem] uppercase tracking-[0.2em] text-copper/80">
          digital · design · systems
        </span>
      </span>
    </Link>
  );
}

export default function PublicLayout() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    setOpen(false);
    window.scrollTo(0, 0);
  }, [pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="min-h-screen">
      <header
        className={cn(
          "sticky top-0 z-40 transition-all duration-300",
          scrolled
            ? "border-b border-white/40 bg-white/75 backdrop-blur-xl shadow-[0_1px_20px_-8px_rgba(22,86,92,0.18)]"
            : "bg-transparent",
        )}
      >
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-6 px-6 py-4 sm:px-8">
          <Logo />

          {/* Desktop nav */}
          <nav className="hidden items-center gap-0 lg:flex">
            {publicNav.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                className={({ isActive }) =>
                  cn(
                    "relative px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.12em] text-slate transition-colors hover:text-charcoal",
                    isActive && "text-charcoal after:absolute after:bottom-0 after:left-4 after:right-4 after:h-[1.5px] after:bg-aqua after:content-['']",
                  )
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>

          {/* Desktop actions */}
          <div className="hidden items-center gap-5 lg:flex">
            <Link
              to="/login"
              className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-slate transition-colors hover:text-charcoal"
            >
              Client login
            </Link>
            <Button asChild size="sm" className="bg-aqua px-5 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a project</Link>
            </Button>
          </div>

          {/* Mobile hamburger */}
          <button
            className="rounded-md p-1.5 text-charcoal lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        {/* Mobile drawer */}
        {open && (
          <div className="border-t border-white/40 bg-white/90 backdrop-blur-xl lg:hidden">
            <nav className="flex flex-col px-6 py-3">
              {publicNav.map((n) => (
                <NavLink
                  key={n.to}
                  to={n.to}
                  className={({ isActive }) =>
                    cn(
                      "border-b border-border py-3.5 font-mono text-[0.75rem] uppercase tracking-[0.12em] text-slate",
                      isActive && "text-aqua",
                    )
                  }
                >
                  {n.label}
                </NavLink>
              ))}
            </nav>
            <div className="flex flex-col gap-2.5 px-6 pb-5 pt-3">
              <Button asChild variant="outline" className="w-full border-border text-slate">
                <Link to="/login">Client login</Link>
              </Button>
              <Button asChild className="w-full bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/start">Start a project</Link>
              </Button>
            </div>
          </div>
        )}
      </header>

      <main>
        <Outlet />
      </main>

      <Footer />
    </div>
  );
}

function Footer() {
  const cols = [
    {
      h: "Company",
      links: [
        ["About", "/about"],
        ["Services", "/services"],
        ["Pricing", "/pricing"],
        ["Contact", "/contact"],
      ],
    },
    {
      h: "Services",
      links: [
        ["Monthly Support", "/care"],
        ["Client Platform", "/platform-overview"],
        ["Start a project", "/start"],
      ],
    },
    {
      h: "Clients",
      links: [["Client login", "/login"]],
    },
    {
      h: "Legal",
      links: [
        ["Privacy Policy", "/privacy"],
        ["Service Terms", "/terms"],
      ],
    },
  ] as const;

  return (
    <footer className="px-6 pb-10 pt-14 sm:px-8">
      <div className="mx-auto max-w-7xl border-t border-border pt-12">
        <div className="grid gap-10 md:grid-cols-[1.6fr_repeat(4,1fr)]">
          <div className="flex flex-col gap-4">
            <Logo />
            <p className="max-w-xs text-[0.88rem] leading-relaxed text-muted-foreground">
              A woman-owned website management and digital systems studio for
              small businesses.
            </p>
            <Link
              to="/start"
              className="inline-flex w-fit items-center gap-1 text-[0.88rem] text-aqua hover:text-aqua-bright"
            >
              Start a project <ArrowUpRight className="h-3.5 w-3.5" />
            </Link>
          </div>
          {cols.map((c) => (
            <div key={c.h} className="flex flex-col gap-2.5">
              <span className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-copper">
                {c.h}
              </span>
              {c.links.map(([label, to]) => (
                <Link
                  key={to}
                  to={to}
                  className="text-[0.88rem] text-slate transition-colors hover:text-charcoal"
                >
                  {label}
                </Link>
              ))}
            </div>
          ))}
        </div>
        <div className="mt-12 flex flex-col items-start justify-between gap-2 border-t border-border pt-5 text-[0.78rem] text-muted-foreground sm:flex-row sm:items-center">
          <span>© {new Date().getFullYear()} Aalia Systems. Woman-owned digital studio.</span>
          <span className="font-mono">Prototype · concept demonstration · sample data</span>
        </div>
      </div>
    </footer>
  );
}
