import { Link, NavLink, Outlet, useLocation } from "react-router";
import { useEffect, useState } from "react";
import { Menu, X, Sparkles, Bell, ChevronDown, LogOut } from "lucide-react";
import { Icon } from "../shared/icon";
import { StatusPill } from "../shared/status";
import { platformNav, clientProfile } from "../../data/mock";
import { cn } from "../ui/utils";

export default function PlatformLayout() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-[260px] transform border-r border-white/50 bg-white/70 backdrop-blur-2xl transition-transform lg:static lg:translate-x-0",
          open ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex h-full flex-col p-4">
          <div className="flex items-center justify-between px-1 py-2">
            <Link to="/platform" className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-aqua text-cream">
                <Sparkles className="h-4 w-4" />
              </span>
              <span className="flex flex-col leading-none">
                <span className="font-display text-[1rem] text-charcoal">Aalia</span>
                <span className="font-mono text-[0.58rem] uppercase tracking-[0.2em] text-copper">client platform</span>
              </span>
            </Link>
            <button className="rounded-lg p-1.5 lg:hidden" onClick={() => setOpen(false)}>
              <X className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-3 rounded-xl border border-white/60 bg-cream/70 p-3">
            <div className="text-[0.6rem] font-mono uppercase tracking-[0.16em] text-muted-foreground">Workspace</div>
            <div className="mt-0.5 truncate text-[0.92rem] text-charcoal">{clientProfile.business}</div>
            <div className="mt-1"><StatusPill tone="aqua">{clientProfile.plan.split(" + ")[0]}</StatusPill></div>
          </div>

          <nav className="mt-4 flex-1 space-y-0.5 overflow-y-auto pr-1">
            {platformNav.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.end}
                className={({ isActive }) =>
                  cn(
                    "flex items-center gap-3 rounded-xl px-3 py-2.5 text-[0.9rem] text-slate transition-colors hover:bg-white/80",
                    isActive && "bg-aqua text-cream hover:bg-aqua",
                  )
                }
              >
                <Icon name={n.icon} className="h-4 w-4 shrink-0" />
                {n.label}
              </NavLink>
            ))}
          </nav>

          <Link
            to="/login"
            className="mt-3 flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[0.9rem] text-slate hover:bg-white/80"
          >
            <LogOut className="h-4 w-4" /> Sign out
          </Link>
        </div>
      </aside>

      {open && <div className="fixed inset-0 z-40 bg-charcoal/20 backdrop-blur-sm lg:hidden" onClick={() => setOpen(false)} />}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-white/50 bg-white/50 px-4 py-3 backdrop-blur-xl sm:px-6">
          <button className="rounded-lg p-2 lg:hidden" onClick={() => setOpen(true)} aria-label="Open menu">
            <Menu className="h-5 w-5" />
          </button>
          <div className="hidden text-[0.85rem] text-muted-foreground sm:block">
            Signed in as <span className="text-charcoal">Naomi Bright</span> · Client Owner
          </div>
          <div className="flex items-center gap-2">
            <button className="relative rounded-xl border border-white/60 bg-white/60 p-2 text-slate hover:text-charcoal">
              <Bell className="h-4 w-4" />
              <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-copper" />
            </button>
            <button className="flex items-center gap-2 rounded-xl border border-white/60 bg-white/60 px-2 py-1.5 text-slate hover:text-charcoal">
              <span className="flex h-6 w-6 items-center justify-center rounded-lg bg-blush text-[0.7rem] text-charcoal">NB</span>
              <ChevronDown className="h-3.5 w-3.5" />
            </button>
          </div>
        </header>
        <main className="flex-1">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
