/**
 * Mock / seed data for the Aalia Systems prototype.
 * All figures are illustrative — labeled as sample data in the UI.
 */

export const services = [
  { id: "design", title: "Website Design", blurb: "Custom websites built around your business, brand, and client experience.", icon: "LayoutTemplate" },
  { id: "redesign", title: "Website Redesign", blurb: "Refresh an outdated site without losing what already works.", icon: "RefreshCw" },
  { id: "care", title: "Monthly Managed Support", blurb: "Monthly updates, monitoring notes, maintenance, and support.", icon: "ShieldCheck" },
  { id: "domain", title: "Domain + Hosting Coordination", blurb: "Help organizing domain, DNS, hosting, SSL, renewals, and provider records.", icon: "Globe" },
  { id: "content", title: "Content Updates", blurb: "Approved text, images, sections, announcements, and service updates.", icon: "FileEdit" },
  { id: "brand", title: "Brand Identity Support", blurb: "Colors, typography, logo direction, style guides, and visual consistency.", icon: "Palette" },
  { id: "docs", title: "Business Documents + Fillable Forms", blurb: "Client forms, intake documents, PDFs, and branded templates.", icon: "FileText" },
  { id: "ecom", title: "E-Commerce Setup", blurb: "Shop setup and support using established platforms.", icon: "ShoppingBag" },
  { id: "pos", title: "POS + Business Systems Support", blurb: "Setup coordination and workflow support for retail/business systems.", icon: "Terminal" },
  { id: "platform", title: "Client Platform", blurb: "A private workspace for updates, requests, invoices, files, and status.", icon: "LayoutDashboard" },
];

export const homeServiceCards = [
  "Website design", "Website redesign", "Monthly managed support", "Domain + hosting coordination",
  "Website maintenance", "Content updates", "Brand identity", "Business documents",
  "Fillable forms", "E-commerce setup", "POS setup support", "Client dashboard",
];

export const howItWorks = [
  { n: "01", title: "Tell us what your business needs", body: "Share your goals, current site, and where you feel stuck." },
  { n: "02", title: "We design or organize your website", body: "We build or restructure your site around your brand and clients." },
  { n: "03", title: "You review and approve", body: "See it in your platform, request changes, and approve with confidence." },
  { n: "04", title: "Your site moves into managed care", body: "Ongoing checks, updates, and human support — organized in one place." },
];

export const serviceModels = [
  { id: "onetime", name: "One-Time Website Project", price: "Starting at $—", desc: "A complete website designed, built, and handed off.", features: ["Custom design", "Up to defined page count", "Launch coordination", "Handoff walkthrough"], featured: false },
  { id: "care", name: "Monthly Support", price: "Monthly from $—", desc: "Ongoing updates, checks, and support after launch.", features: ["Monthly checks", "Update requests", "Maintenance notes", "Client platform access"], featured: true },
  { id: "fractional", name: "Contractor / Fractional Support", price: "Custom quote", desc: "Long-term design + systems support for growing teams.", features: ["Retained hours", "Priority requests", "Systems planning", "Direct coordination"], featured: false },
];

export const heroDashboard = [
  { label: "Website", value: "Online", tone: "ok" as const },
  { label: "SSL", value: "Active", tone: "ok" as const },
  { label: "Domain", value: "Connected", tone: "ok" as const },
  { label: "Maintenance", value: "Checked", tone: "ok" as const },
  { label: "Latest update", value: "Approved", tone: "info" as const },
  { label: "Client request", value: "In review", tone: "warn" as const },
  { label: "Subscription", value: "Active", tone: "aqua" as const },
];

export const platformPreviewCards = [
  "Website status", "Domain status", "SSL status", "Analytics", "Update requests",
  "Files", "Invoices", "Subscriptions", "Support tickets", "Tutorials", "SEO resources",
];

export const mockSites = [
  { id: "service", type: "Service business", pages: ["Home", "Services", "About", "Contact"], features: ["Booking CTA", "Service list", "Reviews block"], img: "photo-1497366216548-37526070297c" },
  { id: "beauty", type: "Beauty / hair / retail", pages: ["Home", "Menu", "Gallery", "Book"], features: ["Gallery", "Online booking", "Product shelf"], img: "photo-1560066984-138dadb4c035" },
  { id: "office", type: "Professional office", pages: ["Home", "Team", "Services", "Contact"], features: ["Team profiles", "Intake form", "Map"], img: "photo-1497366811353-6870744d04b2" },
  { id: "wellness", type: "Healthcare-adjacent practice", pages: ["Home", "Care", "Forms", "Contact"], features: ["Forms routing", "Hours", "Directions"], img: "photo-1519494026892-80bbd2d6fd0d" },
  { id: "ecom", type: "E-commerce shop", pages: ["Shop", "Product", "Cart", "About"], features: ["Product grid", "Cart", "Payments"], img: "photo-1441986300917-64674bd600d8" },
  { id: "coach", type: "Consultant / coach", pages: ["Home", "Programs", "About", "Book"], features: ["Program cards", "Scheduling", "Newsletter"], img: "photo-1522202176988-66273c2fd55f" },
  { id: "realestate", type: "Real estate / professional office", pages: ["Home", "Listings", "Agents", "Contact"], features: ["Listing cards", "Lead form", "Map"], img: "photo-1560518883-ce09059eeffa" },
  { id: "community", type: "Community organization", pages: ["Home", "Programs", "Events", "Donate"], features: ["Events", "Volunteer form", "Donations"], img: "photo-1521737604893-d14cc237f11d" },
];

export const careIncludes = [
  "Website status check", "SSL check", "Domain renewal tracking", "Broken link notes",
  "Mobile review", "Form test", "Update requests", "Content changes",
  "Monthly notes", "Basic analytics snapshot", "Maintenance report",
];

export const careNotIncluded = [
  "Full cybersecurity service", "Guaranteed protection", "Formal security certification",
  "Custom feature development", "Third-party software licensing",
];

// ---- Client platform seed data ----
export const clientProfile = {
  business: "Marigold & Co. Studio",
  plan: "Managed Website + Client Platform",
  website: "marigoldco.studio",
  supportStatus: "Responsive",
  nextAction: "Approve 2 files in review",
};

export const dashboardCards = [
  { key: "site", label: "Website", value: "Online", tone: "ok" as const, note: "Last checked Jul 21, 2026" },
  { key: "domain", label: "Domain", value: "Connected", tone: "ok" as const, note: "Renews Mar 2, 2027" },
  { key: "ssl", label: "SSL", value: "Active", tone: "ok" as const, note: "Auto-renew on" },
  { key: "care", label: "Monthly support", value: "Active", tone: "aqua" as const, note: "Next check Aug 1" },
  { key: "invoice", label: "Invoice", value: "Paid", tone: "ok" as const, note: "#AAL-1042 · $480" },
  { key: "sub", label: "Subscription", value: "Active", tone: "aqua" as const, note: "Renews Aug 5, 2026" },
  { key: "request", label: "Latest request", value: "In review", tone: "warn" as const, note: "Add August promo banner" },
  { key: "analytics", label: "Analytics", value: "+12% MoM", tone: "info" as const, note: "Sample data" },
];

export const requests = [
  { id: "REQ-231", title: "Add August promo banner", type: "New announcement", priority: "High", section: "Home / Hero", status: "In review", date: "Jul 20" },
  { id: "REQ-230", title: "Update team headshot", type: "Image swap", priority: "Normal", section: "About / Team", status: "In progress", date: "Jul 18" },
  { id: "REQ-228", title: "New service: bridal styling", type: "Service update", priority: "Normal", section: "Services", status: "Waiting on client", date: "Jul 14" },
  { id: "REQ-224", title: "Change Sunday hours", type: "Business hours change", priority: "Low", section: "Footer", status: "Resolved", date: "Jul 8" },
];

export const files = [
  { id: "f1", name: "logo-primary.svg", kind: "Logo", status: "Approved", date: "Jul 12", by: "Aalia" },
  { id: "f2", name: "summer-hero.jpg", kind: "Image", status: "In review", date: "Jul 20", by: "You" },
  { id: "f3", name: "brand-guide-v2.pdf", kind: "Brand file", status: "Approved", date: "Jun 30", by: "Aalia" },
  { id: "f4", name: "services-copy.docx", kind: "Website copy", status: "In review", date: "Jul 19", by: "You" },
  { id: "f5", name: "team-photo-2026.jpg", kind: "Image", status: "Changes requested", date: "Jul 16", by: "Aalia" },
];

export const invoices = [
  { id: "AAL-1042", amount: "$480.00", status: "Paid", due: "Jul 5, 2026", paid: "Jul 3, 2026" },
  { id: "AAL-1031", amount: "$480.00", status: "Paid", due: "Jun 5, 2026", paid: "Jun 4, 2026" },
  { id: "AAL-1055", amount: "$1,200.00", status: "Due", due: "Aug 5, 2026", paid: "—" },
  { id: "AAL-1020", amount: "$480.00", status: "Paid", due: "May 5, 2026", paid: "May 5, 2026" },
];

export const subscription = {
  plan: "Managed Website + Client Platform",
  amount: "$480 / month",
  status: "Active",
  renews: "Aug 5, 2026",
  nextInvoice: "Aug 5, 2026",
  included: ["Monthly managed support", "Client platform access", "Up to 4 update requests / mo", "Analytics snapshot", "Priority support"],
};

export const tickets = [
  { id: "TCK-88", title: "Contact form not sending", type: "Bug", urgency: "High", page: "Contact", status: "In progress", updated: "Jul 21" },
  { id: "TCK-85", title: "Add staff login note", type: "Question", urgency: "Low", page: "General", status: "Waiting on client", updated: "Jul 17" },
  { id: "TCK-80", title: "Slow load on gallery", type: "Performance", urgency: "Normal", page: "Gallery", status: "Resolved", updated: "Jul 10" },
];

export const tutorials = [
  { title: "How to request a website update", mins: 3 },
  { title: "How to upload images", mins: 2 },
  { title: "How to approve files", mins: 2 },
  { title: "How to read your monthly report", mins: 4 },
  { title: "How to understand SEO basics", mins: 6 },
  { title: "How to manage domain renewal", mins: 3 },
  { title: "How to use Square invoice links", mins: 2 },
];

export const seoResources = [
  { title: "SEO basics", body: "How search engines find and rank your pages." },
  { title: "Google Business Profile", body: "Keep your listing complete and current for local search." },
  { title: "Page titles", body: "Write clear, unique titles for every page." },
  { title: "Meta descriptions", body: "Summarize each page in ~150 characters." },
  { title: "Image alt text", body: "Describe images for accessibility and search." },
  { title: "Local SEO", body: "Consistent name, address, phone across the web." },
  { title: "Website speed", body: "Faster pages rank and convert better." },
  { title: "Accessibility", body: "Accessible sites reach more people and rank well." },
  { title: "Content freshness", body: "Update key pages regularly to stay relevant." },
];

export const analytics = {
  visitors: [
    { m: "Feb", v: 820 }, { m: "Mar", v: 910 }, { m: "Apr", v: 1040 },
    { m: "May", v: 980 }, { m: "Jun", v: 1180 }, { m: "Jul", v: 1320 },
  ],
  topPages: [
    { page: "/", views: 540 }, { page: "/services", views: 312 },
    { page: "/book", views: 248 }, { page: "/about", views: 176 },
  ],
  sources: [
    { name: "Search", value: 48 }, { name: "Direct", value: 27 },
    { name: "Social", value: 16 }, { name: "Referral", value: 9 },
  ],
  searchClicks: 611,
  formSubmissions: 43,
};

export const platformNav = [
  { to: "/platform", label: "Overview", icon: "LayoutDashboard", end: true },
  { to: "/platform/website", label: "Website", icon: "Globe" },
  { to: "/platform/domain", label: "Domain + Hosting", icon: "Server" },
  { to: "/platform/requests", label: "Requests", icon: "MessageSquarePlus" },
  { to: "/platform/edit", label: "Brand-Safe Edits", icon: "PenSquare" },
  { to: "/platform/files", label: "Files", icon: "FolderOpen" },
  { to: "/platform/invoices", label: "Invoices", icon: "Receipt" },
  { to: "/platform/subscriptions", label: "Subscriptions", icon: "RefreshCw" },
  { to: "/platform/analytics", label: "Analytics", icon: "BarChart3" },
  { to: "/platform/tutorials", label: "Tutorials", icon: "GraduationCap" },
  { to: "/platform/seo", label: "SEO Resources", icon: "Search" },
  { to: "/platform/tickets", label: "Support", icon: "LifeBuoy" },
  { to: "/platform/settings", label: "Settings", icon: "Settings" },
];

export const publicNav = [
  { to: "/services", label: "Services" },
  { to: "/care", label: "Monthly Support" },
  { to: "/platform-overview", label: "Client Platform" },
  { to: "/pricing", label: "Pricing" },
  { to: "/about", label: "About" },
];
