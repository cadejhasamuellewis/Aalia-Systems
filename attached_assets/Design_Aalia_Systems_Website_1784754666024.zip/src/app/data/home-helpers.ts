export {
  homeServiceCards,
  howItWorks,
  serviceModels,
  platformPreviewCards,
  mockSites,
} from "./mock";

/** Maps the home "what Aalia does" labels to lucide icon names. */
export const serviceIconMap: Record<string, string> = {
  "Website design": "LayoutTemplate",
  "Website redesign": "RefreshCw",
  "Monthly managed support": "ShieldCheck",
  "Domain + hosting coordination": "Globe",
  "Website maintenance": "Wrench",
  "Content updates": "FileEdit",
  "Brand identity": "Palette",
  "Business documents": "FileText",
  "Fillable forms": "ClipboardList",
  "E-commerce setup": "ShoppingBag",
  "POS setup support": "Terminal",
  "Client dashboard": "LayoutDashboard",
};
