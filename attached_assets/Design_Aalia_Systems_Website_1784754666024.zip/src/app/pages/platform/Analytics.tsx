import { Users, MousePointerClick, Inbox, TrendingUp } from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { Glass, Kicker } from "../../components/shared/glass";
import { FeatureLabel } from "../../components/shared/status";
import { analytics } from "../../data/mock";

const PIE_COLORS = ["#16565c", "#1f7a82", "#b07f45", "#c3d9de"];

export default function Analytics() {
  const first = analytics.visitors[0].v;
  const last = analytics.visitors[analytics.visitors.length - 1].v;
  const mom = Math.round(((last - first) / first) * 100);

  const kpis = [
    { label: "Visitors", value: last.toLocaleString(), note: "Latest month", icon: Users },
    { label: "Search clicks", value: analytics.searchClicks.toLocaleString(), note: "From search results", icon: MousePointerClick },
    { label: "Form submissions", value: analytics.formSubmissions.toLocaleString(), note: "Contact + booking", icon: Inbox },
    { label: "Trend", value: `+${mom}%`, note: "Since first month shown", icon: TrendingUp },
  ];

  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <Kicker>Snapshot</Kicker>
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-[2rem] leading-tight text-charcoal">Analytics snapshot</h1>
          <FeatureLabel state="Planned" />
          <FeatureLabel state="Sample data" />
        </div>
        <p className="max-w-2xl text-[1rem] leading-relaxed text-muted-foreground">
          A high-level view of website activity. Sample data shown — figures are
          illustrative. Live analytics is a planned integration.
        </p>
      </div>

      {/* KPIs */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {kpis.map((k) => (
          <Glass key={k.label} className="flex flex-col gap-2 p-5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-[0.75rem] uppercase tracking-wide text-muted-foreground">{k.label}</span>
              <k.icon className="h-4 w-4 text-aqua" />
            </div>
            <div className="font-mono text-[1.6rem] text-charcoal">{k.value}</div>
            <div className="text-[0.8rem] text-muted-foreground">{k.note}</div>
          </Glass>
        ))}
      </div>

      {/* Visitors area chart */}
      <Glass className="mt-6 p-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h2 className="text-[1.1rem] text-charcoal">Visitors over time</h2>
          <FeatureLabel state="Sample data" />
        </div>
        <div className="mt-5 h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={analytics.visitors} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
              <defs>
                <linearGradient id="visGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#1f7a82" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#1f7a82" stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#c3d9de" strokeOpacity={0.5} />
              <XAxis dataKey="m" stroke="#5c6b78" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis stroke="#5c6b78" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip
                contentStyle={{ borderRadius: 12, border: "1px solid #c3d9de", fontSize: 12 }}
                labelStyle={{ color: "#16565c" }}
              />
              <Area type="monotone" dataKey="v" name="Visitors" stroke="#16565c" strokeWidth={2} fill="url(#visGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </Glass>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Top pages bar chart */}
        <Glass className="p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-[1.1rem] text-charcoal">Top pages</h2>
            <FeatureLabel state="Sample data" />
          </div>
          <div className="mt-5 h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={analytics.topPages} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#c3d9de" strokeOpacity={0.5} vertical={false} />
                <XAxis dataKey="page" stroke="#5c6b78" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="#5c6b78" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, border: "1px solid #c3d9de", fontSize: 12 }}
                  labelStyle={{ color: "#16565c" }}
                  cursor={{ fill: "#c3d9de", fillOpacity: 0.3 }}
                />
                <Bar dataKey="views" name="Views" fill="#1f7a82" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Glass>

        {/* Sources pie chart */}
        <Glass className="p-6">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-[1.1rem] text-charcoal">Traffic sources</h2>
            <FeatureLabel state="Sample data" />
          </div>
          <div className="mt-5 flex flex-col items-center gap-4 sm:flex-row">
            <div className="h-56 w-full sm:w-1/2">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={analytics.sources}
                    dataKey="value"
                    nameKey="name"
                    innerRadius={44}
                    outerRadius={78}
                    paddingAngle={2}
                  >
                    {analytics.sources.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ borderRadius: 12, border: "1px solid #c3d9de", fontSize: 12 }}
                    formatter={(v: number) => `${v}%`}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <ul className="grid w-full gap-2 sm:w-1/2">
              {analytics.sources.map((s, i) => (
                <li key={s.name} className="flex items-center justify-between text-[0.88rem]">
                  <span className="flex items-center gap-2 text-slate">
                    <span className="h-2.5 w-2.5 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                    {s.name}
                  </span>
                  <span className="font-mono text-charcoal">{s.value}%</span>
                </li>
              ))}
            </ul>
          </div>
        </Glass>
      </div>

      <p className="mt-6 text-[0.8rem] text-muted-foreground">
        Planned integration / sample data. In the live build, figures connect to your
        real analytics provider.
      </p>
    </div>
  );
}
