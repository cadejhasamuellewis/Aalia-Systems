import { Link } from "react-router";
import { ArrowRight, ShieldCheck, TrendingUp } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { StatusPill, StatusRow, FeatureLabel } from "../../components/shared/status";
import {
  clientProfile,
  dashboardCards,
  requests,
  invoices,
  subscription,
  analytics,
} from "../../data/mock";

const statusToneMap: Record<string, "ok" | "info" | "warn" | "muted" | "aqua"> = {
  New: "info",
  "In review": "warn",
  "Waiting on client": "warn",
  "In progress": "info",
  "In progress ": "info",
  Resolved: "ok",
  Closed: "muted",
};

function reqTone(status: string) {
  return statusToneMap[status] ?? "muted";
}

export default function Overview() {
  const openRequests = requests.filter((r) => r.status !== "Resolved" && r.status !== "Closed");
  const latestVisitors = analytics.visitors[analytics.visitors.length - 1].v;
  const dueInvoice = invoices.find((i) => i.status === "Due");

  return (
    <div className="p-5 sm:p-8">
      {/* Page header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[2rem] leading-tight text-charcoal">
            Welcome back, <span className="text-aqua">Naomi.</span>
          </h1>
          <p className="mt-2 max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
            Your website, care plan, and requests — organized in one secure workspace.
          </p>
        </div>
        <FeatureLabel state="Sample data" />
      </div>

      {/* Summary strip */}
      <Glass className="mt-6 grid gap-5 p-5 sm:grid-cols-2 lg:grid-cols-5 lg:p-6" tint="ice">
        <div>
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.16em] text-muted-foreground">Business</div>
          <div className="mt-1 text-[0.95rem] text-charcoal">{clientProfile.business}</div>
        </div>
        <div>
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.16em] text-muted-foreground">Website</div>
          <div className="mt-1.5"><StatusPill tone="ok">Online</StatusPill></div>
        </div>
        <div>
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.16em] text-muted-foreground">Current plan</div>
          <div className="mt-1 text-[0.9rem] text-charcoal">{clientProfile.plan}</div>
        </div>
        <div>
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.16em] text-muted-foreground">Next action</div>
          <div className="mt-1 text-[0.9rem] text-charcoal">{clientProfile.nextAction}</div>
        </div>
        <div>
          <div className="font-mono text-[0.6rem] uppercase tracking-[0.16em] text-muted-foreground">Support</div>
          <div className="mt-1.5"><StatusPill tone="aqua">{clientProfile.supportStatus}</StatusPill></div>
        </div>
      </Glass>

      {/* Status cards */}
      <div className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
        {dashboardCards.map((c) => (
          <Glass key={c.key} className="flex flex-col gap-3 p-4 transition-transform hover:-translate-y-0.5">
            <div className="flex items-center justify-between gap-2">
              <span className="text-[0.85rem] text-muted-foreground">{c.label}</span>
              <StatusPill tone={c.tone} dot={false}>{c.value}</StatusPill>
            </div>
            <span className="font-mono text-[0.72rem] text-slate">{c.note}</span>
          </Glass>
        ))}
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        {/* Open requests */}
        <Glass className="flex flex-col p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-[1.15rem] text-charcoal">Open requests</h2>
            <Button asChild variant="outline" size="sm" className="border-aqua/30 text-aqua hover:bg-white">
              <Link to="/platform/requests">View all <ArrowRight className="ml-1 h-3.5 w-3.5" /></Link>
            </Button>
          </div>
          <div className="mt-3 divide-y divide-border/60">
            {openRequests.length === 0 && (
              <p className="py-6 text-[0.9rem] text-muted-foreground">No open requests. You're all caught up.</p>
            )}
            {openRequests.map((r) => (
              <Link
                key={r.id}
                to="/platform/requests"
                className="flex items-center justify-between gap-3 py-3 transition-colors hover:text-aqua"
              >
                <div className="min-w-0">
                  <div className="truncate text-[0.92rem] text-charcoal">{r.title}</div>
                  <div className="font-mono text-[0.7rem] text-muted-foreground">{r.id} · {r.section} · {r.date}</div>
                </div>
                <StatusPill tone={reqTone(r.status)} dot={false}>{r.status}</StatusPill>
              </Link>
            ))}
          </div>
        </Glass>

        {/* Quick actions */}
        <Glass className="flex flex-col gap-3 p-6">
          <h2 className="text-[1.15rem] text-charcoal">Quick actions</h2>
          <Button asChild className="justify-start bg-aqua text-cream hover:bg-aqua-bright">
            <Link to="/platform/requests">New update request</Link>
          </Button>
          <Button asChild variant="outline" className="justify-start border-aqua/30 text-aqua hover:bg-white">
            <Link to="/platform/edit">Brand-safe edit area</Link>
          </Button>
          <Button asChild variant="outline" className="justify-start border-aqua/30 text-aqua hover:bg-white">
            <Link to="/platform/invoices">View invoices</Link>
          </Button>
          <div className="mt-2 flex items-start gap-2 rounded-xl border border-white/60 bg-cream/60 p-3">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-aqua" />
            <p className="text-[0.78rem] leading-relaxed text-slate">
              Your data stays isolated to your workspace. No card data is stored — payments are handled by Square.
            </p>
          </div>
        </Glass>
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-3">
        {/* Invoice + subscription */}
        <Glass className="flex flex-col p-6 lg:col-span-2">
          <h2 className="text-[1.15rem] text-charcoal">Billing status</h2>
          <div className="mt-2">
            <StatusRow label="Subscription">
              <StatusPill tone="aqua" dot={false}>{subscription.status}</StatusPill>
            </StatusRow>
            <StatusRow label="Plan amount">
              <span className="font-mono text-[0.82rem] text-charcoal">{subscription.amount}</span>
            </StatusRow>
            <StatusRow label="Renews">
              <span className="font-mono text-[0.82rem] text-charcoal">{subscription.renews}</span>
            </StatusRow>
            {dueInvoice && (
              <StatusRow label={`Invoice #${dueInvoice.id}`}>
                <span className="flex items-center gap-2">
                  <span className="font-mono text-[0.82rem] text-charcoal">{dueInvoice.amount}</span>
                  <StatusPill tone="warn" dot={false}>Due {dueInvoice.due}</StatusPill>
                </span>
              </StatusRow>
            )}
          </div>
          <Button asChild variant="outline" className="mt-4 w-fit border-aqua/30 text-aqua hover:bg-white">
            <Link to="/platform/subscriptions">Manage subscription</Link>
          </Button>
        </Glass>

        {/* Analytics teaser */}
        <Glass className="flex flex-col p-6" tint="cream">
          <div className="flex items-center justify-between">
            <h2 className="text-[1.15rem] text-charcoal">Analytics</h2>
            <FeatureLabel state="Sample data" />
          </div>
          <div className="mt-4 flex items-end gap-2">
            <span className="font-mono text-[2rem] leading-none text-aqua">{latestVisitors.toLocaleString()}</span>
            <span className="mb-1 flex items-center gap-1 text-[0.82rem] text-[#2f6d46]">
              <TrendingUp className="h-3.5 w-3.5" /> +12% MoM
            </span>
          </div>
          <p className="mt-1 text-[0.82rem] text-muted-foreground">Visitors this month</p>
          <Button asChild variant="outline" className="mt-4 w-fit border-aqua/30 text-aqua hover:bg-white">
            <Link to="/platform/analytics">Open analytics</Link>
          </Button>
        </Glass>
      </div>
    </div>
  );
}
