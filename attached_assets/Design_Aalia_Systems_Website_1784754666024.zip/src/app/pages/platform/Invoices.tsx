import { CreditCard, Download, Receipt, ShieldCheck, Lock } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass, Kicker } from "../../components/shared/glass";
import { StatusPill, FeatureLabel } from "../../components/shared/status";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import { invoices } from "../../data/mock";
import { toast } from "sonner";

function parseAmount(a: string) {
  return Number(a.replace(/[^0-9.]/g, ""));
}

function money(n: number) {
  return n.toLocaleString("en-US", { style: "currency", currency: "USD" });
}

export default function Invoices() {
  const paid = invoices.filter((i) => i.status === "Paid");
  const due = invoices.filter((i) => i.status === "Due");
  const totalPaid = paid.reduce((s, i) => s + parseAmount(i.amount), 0);
  const amountDue = due.reduce((s, i) => s + parseAmount(i.amount), 0);
  const nextInvoice = due[0];

  const summary = [
    { label: "Total paid", value: money(totalPaid), note: `${paid.length} invoices settled`, icon: ShieldCheck },
    { label: "Amount due", value: money(amountDue), note: due.length ? `${due.length} awaiting payment` : "Nothing outstanding", icon: CreditCard },
    { label: "Next invoice", value: nextInvoice ? nextInvoice.amount : "—", note: nextInvoice ? `Due ${nextInvoice.due}` : "No upcoming invoice", icon: Receipt },
  ];

  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <Kicker>Billing</Kicker>
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-[2rem] leading-tight text-charcoal">Invoices</h1>
          <FeatureLabel state="Requires payment processor setup" />
        </div>
        <p className="max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
          Review, download, and pay invoices. Payments run securely through Square.
        </p>
      </div>

      {/* Security note */}
      <Glass tint="ice" className="mt-6 flex items-start gap-3 p-5">
        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/70 text-aqua">
          <Lock className="h-4 w-4" />
        </span>
        <div>
          <div className="text-[0.95rem] text-charcoal">Aalia does not store card data.</div>
          <p className="mt-1 text-[0.88rem] leading-relaxed text-muted-foreground">
            Payments are handled through Square's hosted, tokenized payment flow. Card
            details are entered on Square's secure page — never on this platform.
          </p>
        </div>
      </Glass>

      {/* Summary cards */}
      <div className="mt-6 grid gap-4 sm:grid-cols-3">
        {summary.map((s) => (
          <Glass key={s.label} className="flex flex-col gap-2 p-5">
            <div className="flex items-center justify-between">
              <span className="text-[0.8rem] uppercase tracking-wide text-muted-foreground font-mono">{s.label}</span>
              <s.icon className="h-4 w-4 text-aqua" />
            </div>
            <div className="font-mono text-[1.5rem] text-charcoal">{s.value}</div>
            <div className="text-[0.82rem] text-muted-foreground">{s.note}</div>
          </Glass>
        ))}
      </div>

      {/* Table */}
      <Glass className="mt-6 overflow-hidden p-0">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/50 p-5">
          <h2 className="text-[1.1rem] text-charcoal">Invoice history</h2>
          <FeatureLabel state="Requires payment processor setup" />
        </div>
        {invoices.length === 0 ? (
          <div className="flex flex-col items-center gap-2 p-12 text-center">
            <Receipt className="h-8 w-8 text-slate" />
            <div className="text-[0.95rem] text-charcoal">No invoices yet</div>
            <p className="text-[0.85rem] text-muted-foreground">Invoices will appear here once your first one is issued.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Invoice</TableHead>
                  <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Amount</TableHead>
                  <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Status</TableHead>
                  <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Due</TableHead>
                  <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Paid</TableHead>
                  <TableHead className="text-right font-mono text-[0.72rem] uppercase tracking-wide">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((inv) => (
                  <TableRow key={inv.id}>
                    <TableCell className="font-mono text-[0.85rem] text-charcoal">{inv.id}</TableCell>
                    <TableCell className="font-mono text-[0.85rem] text-charcoal">{inv.amount}</TableCell>
                    <TableCell>
                      <StatusPill tone={inv.status === "Paid" ? "ok" : "warn"}>{inv.status}</StatusPill>
                    </TableCell>
                    <TableCell className="text-[0.85rem] text-slate">{inv.due}</TableCell>
                    <TableCell className="text-[0.85rem] text-slate">{inv.paid}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-aqua/30 text-aqua hover:bg-white"
                          onClick={() => toast.success(`Downloading invoice ${inv.id}`)}
                        >
                          <Download className="mr-1.5 h-3.5 w-3.5" /> Invoice
                        </Button>
                        {inv.status === "Paid" ? (
                          <Button
                            variant="outline"
                            size="sm"
                            className="border-aqua/30 text-aqua hover:bg-white"
                            onClick={() => toast.success(`Opening receipt for ${inv.id}`)}
                          >
                            <Receipt className="mr-1.5 h-3.5 w-3.5" /> Receipt
                          </Button>
                        ) : (
                          <Button
                            size="sm"
                            className="bg-aqua text-cream hover:bg-aqua-bright"
                            onClick={() => toast.success(`Redirecting to Square to pay ${inv.id}`)}
                          >
                            <CreditCard className="mr-1.5 h-3.5 w-3.5" /> Pay with Square
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Glass>

      <p className="mt-4 text-[0.8rem] text-muted-foreground">
        Pay actions require Square payment processor setup in the live build.
      </p>
    </div>
  );
}
