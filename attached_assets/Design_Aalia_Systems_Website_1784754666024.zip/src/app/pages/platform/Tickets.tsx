import { useState } from "react";
import { Plus, UploadCloud, LifeBuoy, ArrowLeft, MessageSquare } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Label } from "../../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import { Glass, Kicker } from "../../components/shared/glass";
import { StatusPill, StatusRow } from "../../components/shared/status";
import { tickets as seedTickets } from "../../data/mock";
import { toast } from "sonner";

type Ticket = {
  id: string;
  title: string;
  type: string;
  urgency: string;
  page: string;
  status: string;
  updated: string;
  response?: string;
  resolution?: string;
};

type Tone = "ok" | "info" | "warn" | "muted" | "aqua";

const statusTone: Record<string, Tone> = {
  New: "info",
  "In review": "warn",
  "Waiting on client": "warn",
  "In progress": "aqua",
  Resolved: "ok",
  Closed: "muted",
};

const mockResponse: Record<string, { response: string; resolution: string }> = {
  "TCK-88": {
    response: "Thanks — we've reproduced the issue and identified a misconfigured form endpoint. A fix is in progress.",
    resolution: "Pending — expected within 1 business day.",
  },
  "TCK-85": {
    response: "We can add a staff login note. Could you confirm the exact wording you'd like shown?",
    resolution: "Awaiting your reply.",
  },
  "TCK-80": {
    response: "We compressed gallery images and enabled lazy loading. Load time improved from 4.1s to 1.6s.",
    resolution: "Resolved on Jul 10, 2026.",
  },
};

const STATUS_FILTERS = ["All", "New", "In progress", "Waiting on client", "Resolved", "Closed"];
const ISSUE_TYPES = ["Bug", "Question", "Performance", "Content change", "Other"];
const URGENCIES = ["Low", "Normal", "High"];

export default function Tickets() {
  const [tickets, setTickets] = useState<Ticket[]>(seedTickets);
  const [filter, setFilter] = useState("All");
  const [selected, setSelected] = useState<Ticket | null>(null);
  const [open, setOpen] = useState(false);

  const [title, setTitle] = useState("");
  const [type, setType] = useState("Bug");
  const [urgency, setUrgency] = useState("Normal");
  const [page, setPage] = useState("");
  const [notes, setNotes] = useState("");
  const [fileName, setFileName] = useState("");

  const filtered = filter === "All" ? tickets : tickets.filter((t) => t.status === filter);

  const resetForm = () => {
    setTitle(""); setType("Bug"); setUrgency("Normal"); setPage(""); setNotes(""); setFileName("");
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      toast.error("Please add a ticket title.");
      return;
    }
    const next: Ticket = {
      id: `TCK-${Math.floor(90 + Math.random() * 900)}`,
      title: title.trim(),
      type,
      urgency,
      page: page.trim() || "General",
      status: "New",
      updated: "Just now",
      response: "Received — a team member will review shortly.",
      resolution: "Open",
    };
    setTickets((prev) => [next, ...prev]);
    setOpen(false);
    resetForm();
    toast.success(`Ticket ${next.id} submitted`);
  };

  const view = selected ? (tickets.find((t) => t.id === selected.id) ?? selected) : null;
  const detail = view ? mockResponse[view.id] : undefined;

  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div className="flex flex-col gap-3">
          <Kicker>Support</Kicker>
          <h1 className="text-[2rem] leading-tight text-charcoal">Support tickets</h1>
          <p className="max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
            Report issues, ask questions, and track responses from the Aalia team.
          </p>
        </div>
        <Button className="bg-aqua text-cream hover:bg-aqua-bright" onClick={() => setOpen(true)}>
          <Plus className="mr-1.5 h-4 w-4" /> New ticket
        </Button>
      </div>

      {/* Filter */}
      <div className="mt-6 flex flex-wrap gap-2">
        {STATUS_FILTERS.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`rounded-full border px-3 py-1.5 font-mono text-[0.75rem] transition-colors ${
              filter === f
                ? "border-aqua bg-aqua text-cream"
                : "border-white/60 bg-white/50 text-slate hover:bg-white"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      {view ? (
        /* Detail view */
        <Glass className="mt-6 p-6">
          <button
            onClick={() => setSelected(null)}
            className="flex items-center gap-1.5 text-[0.85rem] text-aqua hover:text-aqua-bright"
          >
            <ArrowLeft className="h-4 w-4" /> Back to tickets
          </button>
          <div className="mt-4 flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="font-mono text-[0.78rem] text-copper">{view.id}</div>
              <h2 className="mt-1 text-[1.4rem] text-charcoal">{view.title}</h2>
            </div>
            <StatusPill tone={statusTone[view.status] ?? "muted"}>{view.status}</StatusPill>
          </div>
          <div className="mt-4 rounded-xl border border-white/60 bg-white/50 p-4">
            <StatusRow label="Issue type"><span className="text-[0.85rem] text-charcoal">{view.type}</span></StatusRow>
            <StatusRow label="Urgency"><span className="text-[0.85rem] text-charcoal">{view.urgency}</span></StatusRow>
            <StatusRow label="Page affected"><span className="text-[0.85rem] text-charcoal">{view.page}</span></StatusRow>
            <StatusRow label="Last updated"><span className="font-mono text-[0.82rem] text-slate">{view.updated}</span></StatusRow>
          </div>

          <div className="mt-5 flex items-start gap-3 rounded-xl border border-aqua/20 bg-aqua/5 p-4">
            <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/70 text-aqua">
              <MessageSquare className="h-4 w-4" />
            </span>
            <div>
              <div className="text-[0.82rem] font-mono uppercase tracking-wide text-copper">Aalia response</div>
              <p className="mt-1 text-[0.9rem] leading-relaxed text-charcoal">
                {detail?.response ?? view.response ?? "No response yet."}
              </p>
            </div>
          </div>
          <div className="mt-3 rounded-xl border border-white/60 bg-white/50 p-4">
            <div className="text-[0.82rem] font-mono uppercase tracking-wide text-muted-foreground">Resolution</div>
            <p className="mt-1 text-[0.9rem] text-slate">{detail?.resolution ?? view.resolution ?? "Open"}</p>
          </div>
        </Glass>
      ) : filtered.length === 0 ? (
        <Glass className="mt-6 flex flex-col items-center gap-2 p-12 text-center">
          <LifeBuoy className="h-8 w-8 text-slate" />
          <div className="text-[0.95rem] text-charcoal">No tickets here</div>
          <p className="text-[0.85rem] text-muted-foreground">
            {filter === "All" ? "You have no tickets yet." : `No tickets with status "${filter}".`}
          </p>
        </Glass>
      ) : (
        /* List */
        <div className="mt-6 grid gap-3">
          {filtered.map((t) => (
            <Glass
              key={t.id}
              className="flex cursor-pointer flex-wrap items-center justify-between gap-3 p-5 transition-transform hover:-translate-y-0.5"
              onClick={() => setSelected(t)}
            >
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[0.72rem] text-copper">{t.id}</span>
                  <span className="text-[0.72rem] text-muted-foreground">· {t.type}</span>
                </div>
                <h3 className="mt-0.5 truncate text-[1rem] text-charcoal">{t.title}</h3>
                <div className="mt-1 font-mono text-[0.75rem] text-muted-foreground">
                  {t.page} · {t.urgency} urgency · Updated {t.updated}
                </div>
              </div>
              <StatusPill tone={statusTone[t.status] ?? "muted"}>{t.status}</StatusPill>
            </Glass>
          ))}
        </div>
      )}

      {/* New ticket dialog */}
      <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) resetForm(); }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>New support ticket</DialogTitle>
            <DialogDescription>Tell us what's happening and we'll take it from here.</DialogDescription>
          </DialogHeader>
          <form onSubmit={submit} className="grid gap-4">
            <div className="grid gap-1.5">
              <Label htmlFor="t-title">Ticket title</Label>
              <Input id="t-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Brief summary of the issue" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label>Issue type</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {ISSUE_TYPES.map((i) => <SelectItem key={i} value={i}>{i}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-1.5">
                <Label>Urgency</Label>
                <Select value={urgency} onValueChange={setUrgency}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {URGENCIES.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="t-page">Website / page affected</Label>
              <Input id="t-page" value={page} onChange={(e) => setPage(e.target.value)} placeholder="e.g. Contact, /services" />
            </div>
            <div className="grid gap-1.5">
              <Label>Screenshot / file</Label>
              <label className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border border-dashed border-aqua/40 bg-ice/30 p-6 text-center transition-colors hover:bg-ice/50">
                <UploadCloud className="h-6 w-6 text-aqua" />
                <span className="text-[0.85rem] text-slate">
                  {fileName || "Drag a file here or click to upload"}
                </span>
                <input
                  type="file"
                  className="hidden"
                  onChange={(e) => setFileName(e.target.files?.[0]?.name ?? "")}
                />
              </label>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="t-notes">Notes</Label>
              <Textarea id="t-notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Any extra detail that helps us understand the issue" rows={3} />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" className="border-aqua/30 text-aqua hover:bg-white" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" className="bg-aqua text-cream hover:bg-aqua-bright">Submit ticket</Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
