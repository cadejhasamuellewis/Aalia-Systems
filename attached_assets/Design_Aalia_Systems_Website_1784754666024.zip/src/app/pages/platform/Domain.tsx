import { useState } from "react";
import { toast } from "sonner";
import { Globe, Server, Mail, ShieldCheck } from "lucide-react";
import { Glass } from "../../components/shared/glass";
import { StatusPill, StatusRow, FeatureLabel } from "../../components/shared/status";
import { Switch } from "../../components/ui/switch";
import { Label } from "../../components/ui/label";
import { clientProfile } from "../../data/mock";

export default function Domain() {
  const [reminder, setReminder] = useState(true);

  function toggleReminder(v: boolean) {
    setReminder(v);
    toast.success(v ? "Renewal reminders on." : "Renewal reminders off.");
  }

  return (
    <div className="p-5 sm:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[2rem] leading-tight text-charcoal">Domain + Hosting</h1>
          <p className="mt-2 max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
            Provider records, renewals, DNS, and email — tracked in one place.
          </p>
        </div>
        <FeatureLabel state="Requires integration" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {/* Domain */}
        <Glass className="flex flex-col p-6">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-ice/70 text-aqua">
              <Globe className="h-4 w-4" />
            </span>
            <h2 className="text-[1.15rem] text-charcoal">Domain</h2>
          </div>
          <div className="mt-3">
            <StatusRow label="Domain name">
              <span className="font-mono text-[0.82rem] text-charcoal">{clientProfile.website}</span>
            </StatusRow>
            <StatusRow label="Registrar">
              <span className="font-mono text-[0.82rem] text-charcoal">Namecheap-style registrar</span>
            </StatusRow>
            <StatusRow label="Renewal date">
              <span className="font-mono text-[0.82rem] text-charcoal">Mar 2, 2027</span>
            </StatusRow>
            <StatusRow label="Auto-renew"><StatusPill tone="ok" dot={false}>On</StatusPill></StatusRow>
            <StatusRow label="DNS status"><StatusPill tone="ok">Healthy</StatusPill></StatusRow>
          </div>
        </Glass>

        {/* Hosting */}
        <Glass className="flex flex-col p-6" tint="ice">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/70 text-aqua">
              <Server className="h-4 w-4" />
            </span>
            <h2 className="text-[1.15rem] text-charcoal">Hosting + SSL</h2>
          </div>
          <div className="mt-3">
            <StatusRow label="Hosting provider">
              <span className="font-mono text-[0.82rem] text-charcoal">Managed by Aalia</span>
            </StatusRow>
            <StatusRow label="SSL certificate"><StatusPill tone="ok">Active</StatusPill></StatusRow>
            <StatusRow label="SSL renews">
              <span className="font-mono text-[0.82rem] text-charcoal">Oct 14, 2026</span>
            </StatusRow>
            <StatusRow label="CDN"><StatusPill tone="ok" dot={false}>Enabled</StatusPill></StatusRow>
          </div>
        </Glass>

        {/* Email */}
        <Glass className="flex flex-col p-6">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-ice/70 text-aqua">
              <Mail className="h-4 w-4" />
            </span>
            <h2 className="text-[1.15rem] text-charcoal">Email</h2>
          </div>
          <div className="mt-3">
            <StatusRow label="Email provider">
              <span className="font-mono text-[0.82rem] text-charcoal">Google Workspace-style</span>
            </StatusRow>
            <StatusRow label="MX records"><StatusPill tone="ok">Verified</StatusPill></StatusRow>
            <StatusRow label="SPF / DKIM"><StatusPill tone="ok" dot={false}>Passing</StatusPill></StatusRow>
          </div>
        </Glass>

        {/* Reminders + notes */}
        <Glass className="flex flex-col p-6" tint="cream">
          <h2 className="text-[1.15rem] text-charcoal">Reminders + notes</h2>
          <div className="mt-4 flex items-center justify-between rounded-xl border border-white/60 bg-white/60 p-3.5">
            <Label htmlFor="renew-reminder" className="text-[0.9rem] text-charcoal">
              Renewal reminders
              <span className="mt-0.5 block text-[0.78rem] font-normal text-muted-foreground">
                Email me 30 days before any renewal.
              </span>
            </Label>
            <Switch id="renew-reminder" checked={reminder} onCheckedChange={toggleReminder} />
          </div>
          <div className="mt-4 flex items-start gap-2 rounded-xl border border-white/60 bg-white/60 p-3">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-aqua" />
            <p className="text-[0.78rem] leading-relaxed text-slate">
              Provider records are coordinated on your behalf. We never store payment card data — renewals use the
              provider's own tokenized checkout.
            </p>
          </div>
          <p className="mt-4 text-[0.85rem] leading-relaxed text-muted-foreground">
            Notes: Domain and hosting are consolidated under Aalia's managed care so renewals never lapse. Reach out via
            Support to transfer providers or update records.
          </p>
        </Glass>
      </div>
    </div>
  );
}
