import { useState } from "react";
import { toast } from "sonner";
import { Plus, UploadCloud, Inbox } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Label } from "../../components/ui/label";
import { Checkbox } from "../../components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "../../components/ui/dialog";
import { Glass } from "../../components/shared/glass";
import { StatusPill } from "../../components/shared/status";
import { cn } from "../../components/ui/utils";
import { requests as seedRequests } from "../../data/mock";

type Req = (typeof seedRequests)[number];

const statusTone: Record<string, "ok" | "info" | "warn" | "muted" | "aqua"> = {
  New: "info",
  "In review": "warn",
  "Waiting on client": "warn",
  "In progress": "info",
  Resolved: "ok",
  Closed: "muted",
};

const requestTypes = [
  "Text change",
  "Image swap",
  "New announcement",
  "Service update",
  "Business hours change",
  "Form update",
  "New page request",
  "Emergency issue",
];

const priorities = ["Low", "Normal", "High"];
const filters = ["All", "New", "In review", "In progress", "Waiting on client", "Resolved"];

export default function Requests() {
  const [items, setItems] = useState<Req[]>(seedRequests);
  const [filter, setFilter] = useState("All");
  const [open, setOpen] = useState(false);

  const [title, setTitle] = useState("");
  const [type, setType] = useState("");
  const [priority, setPriority] = useState("Normal");
  const [section, setSection] = useState("");
  const [newText, setNewText] = useState("");
  const [notes, setNotes] = useState("");
  const [approved, setApproved] = useState(false);

  const shown = filter === "All" ? items : items.filter((i) => i.status === filter);

  function resetForm() {
    setTitle(""); setType(""); setPriority("Normal"); setSection("");
    setNewText(""); setNotes(""); setApproved(false);
  }

  function submit() {
    if (!title.trim() || !type) {
      toast.error("Please add a title and request type.");
      return;
    }
    const next: Req = {
      id: `REQ-${Math.floor(200 + Math.random() * 700)}`,
      title: title.trim(),
      type,
      priority,
      section: section.trim() || "General",
      status: "New",
      date: "Jul 22",
    };
    setItems((prev) => [next, ...prev]);
    toast.success("Request submitted — the Aalia team will review it shortly.");
    resetForm();
    setOpen(false);
  }

  return (
    <div className="p-5 sm:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[2rem] leading-tight text-charcoal">Website update requests</h1>
          <p className="mt-2 max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
            Request approved content changes — no code access required. Everything is reviewed before it goes live.
          </p>
        </div>

        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="bg-aqua text-cream hover:bg-aqua-bright">
              <Plus className="mr-1.5 h-4 w-4" /> New request
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
            <DialogHeader>
              <DialogTitle>New update request</DialogTitle>
              <DialogDescription>
                Describe the change you'd like. Our team applies it within your approved brand rules.
              </DialogDescription>
            </DialogHeader>

            <div className="grid gap-4 py-1">
              <div className="grid gap-1.5">
                <Label htmlFor="r-title">Request title</Label>
                <Input id="r-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Update fall hours" />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="grid gap-1.5">
                  <Label>Request type</Label>
                  <Select value={type} onValueChange={setType}>
                    <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                    <SelectContent>
                      {requestTypes.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-1.5">
                  <Label>Priority</Label>
                  <Select value={priority} onValueChange={setPriority}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {priorities.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="r-section">Page / section affected</Label>
                <Input id="r-section" value={section} onChange={(e) => setSection(e.target.value)} placeholder="e.g. Home / Hero" />
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="r-text">New text</Label>
                <Textarea id="r-text" value={newText} onChange={(e) => setNewText(e.target.value)} placeholder="Paste the exact copy you'd like used…" rows={3} />
              </div>

              <div className="grid gap-1.5">
                <Label>Upload image / file</Label>
                <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-aqua/40 bg-ice/40 px-4 py-6 text-center transition-colors hover:bg-ice/60">
                  <UploadCloud className="h-5 w-5 text-aqua" />
                  <span className="text-[0.82rem] text-charcoal">Drag a file here or click to browse</span>
                  <span className="font-mono text-[0.68rem] text-muted-foreground">PNG, JPG, PDF · up to 20MB</span>
                  <input type="file" className="hidden" />
                </label>
              </div>

              <div className="grid gap-1.5">
                <Label htmlFor="r-notes">Notes</Label>
                <Textarea id="r-notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Anything else we should know?" rows={2} />
              </div>

              <label className="flex items-start gap-2.5 rounded-xl border border-white/60 bg-white/60 p-3">
                <Checkbox checked={approved} onCheckedChange={(v) => setApproved(Boolean(v))} className="mt-0.5" />
                <span className="text-[0.82rem] leading-relaxed text-slate">
                  I approve this change and confirm it stays within my brand guidelines.
                </span>
              </label>
            </div>

            <DialogFooter>
              <Button variant="outline" className="border-aqua/30 text-aqua hover:bg-white" onClick={() => setOpen(false)}>Cancel</Button>
              <Button className="bg-aqua text-cream hover:bg-aqua-bright" onClick={submit} disabled={!approved}>Submit request</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="mt-6 flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "rounded-full border px-3 py-1.5 font-mono text-[0.72rem] tracking-wide transition-colors",
              filter === f
                ? "border-aqua bg-aqua text-cream"
                : "border-white/60 bg-white/50 text-slate hover:bg-white",
            )}
          >
            {f}
          </button>
        ))}
      </div>

      {/* List */}
      {shown.length === 0 ? (
        <Glass className="mt-5 flex flex-col items-center gap-3 p-12 text-center">
          <span className="flex h-12 w-12 items-center justify-center rounded-full bg-ice/70 text-aqua">
            <Inbox className="h-5 w-5" />
          </span>
          <p className="text-[0.95rem] text-charcoal">No requests in this view</p>
          <p className="max-w-sm text-[0.85rem] text-muted-foreground">
            When you submit an update request it will appear here with live status.
          </p>
        </Glass>
      ) : (
        <div className="mt-5 space-y-2.5">
          {shown.map((r) => (
            <Glass key={r.id} className="flex flex-wrap items-center gap-3 p-4">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span className="truncate text-[0.95rem] text-charcoal">{r.title}</span>
                  <span className="font-mono text-[0.68rem] text-muted-foreground">{r.id}</span>
                </div>
                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 font-mono text-[0.7rem] text-muted-foreground">
                  <span>{r.type}</span>
                  <span>· {r.section}</span>
                  <span>· {r.date}</span>
                </div>
              </div>
              <StatusPill
                tone={r.priority === "High" ? "warn" : r.priority === "Low" ? "muted" : "aqua"}
                dot={false}
              >
                {r.priority}
              </StatusPill>
              <StatusPill tone={statusTone[r.status] ?? "muted"} dot={false}>{r.status}</StatusPill>
            </Glass>
          ))}
        </div>
      )}
    </div>
  );
}
