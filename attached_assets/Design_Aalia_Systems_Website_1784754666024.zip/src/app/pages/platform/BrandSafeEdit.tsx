import { useState } from "react";
import { toast } from "sonner";
import { Lock, ShieldCheck, ImageIcon, AlertTriangle, Sparkles } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Label } from "../../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../../components/ui/select";
import { Glass } from "../../components/shared/glass";
import { StatusPill, FeatureLabel } from "../../components/shared/status";

const approvedStyles = ["Display — Fraunces", "Section title", "Emphasis subhead", "Caption"];

export default function BrandSafeEdit() {
  const [heroHeading, setHeroHeading] = useState("Fresh looks, booked with ease");
  const [heroStyle, setHeroStyle] = useState("Display — Fraunces");
  const [heroSubtext, setHeroSubtext] = useState("Modern cuts, color, and bridal styling in the heart of downtown.");
  const [promo, setPromo] = useState("August: 15% off first color service");
  const [cta, setCta] = useState("Book an appointment");
  const [about, setAbout] = useState(
    "Marigold & Co. is a woman-owned studio focused on approachable, elevated styling for every guest.",
  );

  function submit() {
    toast.success("Changes submitted for review — nothing is published until our team approves.");
  }

  return (
    <div className="p-5 sm:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[2rem] leading-tight text-charcoal">Brand-safe edit area</h1>
          <p className="mt-2 max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
            Update approved content — the structure, code, spacing, and brand rules stay protected.
          </p>
        </div>
        <FeatureLabel state="Prototype" />
      </div>

      {/* Explainer banner */}
      <Glass className="mt-6 flex flex-wrap items-center gap-4 p-5" tint="aqua">
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-aqua text-cream">
          <ShieldCheck className="h-5 w-5" />
        </span>
        <p className="min-w-0 flex-1 text-[0.95rem] leading-relaxed text-charcoal">
          Your design stays protected. You can update approved content areas without changing the structure, code,
          spacing, brand rules, or layout. Edits are submitted for review — never published directly.
        </p>
        <div className="flex flex-wrap gap-2">
          <StatusPill tone="ok" dot={false}>No code access</StatusPill>
          <StatusPill tone="ok" dot={false}>Layout locked</StatusPill>
        </div>
      </Glass>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_1fr]">
        {/* Left: approved editable blocks */}
        <Glass className="flex flex-col gap-5 p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-[1.15rem] text-charcoal">Approved content blocks</h2>
            <StatusPill tone="ok" dot={false}>Editable</StatusPill>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="hero-h">Hero heading</Label>
            <Input id="hero-h" value={heroHeading} onChange={(e) => setHeroHeading(e.target.value)} />
          </div>

          <div className="grid gap-1.5">
            <Label>Approved heading style</Label>
            <Select value={heroStyle} onValueChange={setHeroStyle}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {approvedStyles.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
            <span className="font-mono text-[0.68rem] text-muted-foreground">
              Only pre-approved styles are available — free-form styling is disabled.
            </span>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="hero-sub">Hero subtext</Label>
            <Textarea id="hero-sub" value={heroSubtext} onChange={(e) => setHeroSubtext(e.target.value)} rows={2} />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="promo">Promo banner text</Label>
            <Input id="promo" value={promo} onChange={(e) => setPromo(e.target.value)} />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="cta">Approved CTA text</Label>
            <Input id="cta" value={cta} onChange={(e) => setCta(e.target.value)} />
          </div>

          <div className="grid gap-1.5">
            <Label>Featured image slot</Label>
            <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-aqua/40 bg-ice/40 px-4 py-6 text-center transition-colors hover:bg-ice/60">
              <ImageIcon className="h-5 w-5 text-aqua" />
              <span className="text-[0.82rem] text-charcoal">Replace featured image</span>
              <span className="font-mono text-[0.68rem] text-muted-foreground">Approved dimensions: 1600 × 900 · JPG/PNG</span>
              <input type="file" accept="image/*" className="hidden" />
            </label>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="about">About paragraph</Label>
            <Textarea id="about" value={about} onChange={(e) => setAbout(e.target.value)} rows={3} />
          </div>
        </Glass>

        {/* Right: locked-layout preview */}
        <div className="flex flex-col gap-4">
          <Glass className="flex flex-col gap-3 p-6" tint="ice">
            <div className="flex items-center justify-between">
              <h2 className="text-[1.15rem] text-charcoal">Locked-layout preview</h2>
              <span className="font-mono text-[0.68rem] uppercase tracking-wide text-muted-foreground">Structure fixed</span>
            </div>

            {/* Editable region: hero */}
            <div className="rounded-xl border-2 border-dashed border-[#bfe0cc] bg-[#e2efe6]/50 p-4">
              <span className="font-mono text-[0.62rem] uppercase tracking-wide text-[#2f6d46]">Editable · hero</span>
              <div className="mt-2 text-[1.25rem] leading-tight text-charcoal">{heroHeading}</div>
              <p className="mt-1 text-[0.85rem] text-slate">{heroSubtext}</p>
              <span className="mt-3 inline-flex rounded-lg bg-aqua px-3 py-1.5 text-[0.8rem] text-cream">{cta}</span>
            </div>

            {/* Editable region: promo */}
            <div className="rounded-xl border-2 border-dashed border-[#bfe0cc] bg-[#e2efe6]/50 p-3">
              <span className="font-mono text-[0.62rem] uppercase tracking-wide text-[#2f6d46]">Editable · promo</span>
              <div className="mt-1 text-[0.9rem] text-charcoal">{promo}</div>
            </div>

            {/* Locked regions */}
            {["Navigation bar", "Column grid + spacing", "Footer + brand mark"].map((r) => (
              <div key={r} className="flex items-center gap-2.5 rounded-xl border border-border/70 bg-muted/40 p-3">
                <Lock className="h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                <span className="text-[0.82rem] text-muted-foreground">{r}</span>
                <span className="ml-auto font-mono text-[0.62rem] uppercase tracking-wide text-muted-foreground">Locked</span>
              </div>
            ))}
          </Glass>

          {/* Approved section templates */}
          <Glass className="flex flex-col gap-3 p-6">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-aqua" />
              <h2 className="text-[1.05rem] text-charcoal">Approved section templates</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {["Hero + CTA", "Promo banner", "Service list", "Gallery grid", "About block"].map((t) => (
                <span key={t} className="rounded-full border border-white/60 bg-white/60 px-3 py-1.5 text-[0.8rem] text-slate">{t}</span>
              ))}
            </div>
          </Glass>

          {/* Brand-rule warning */}
          <Glass className="flex items-start gap-2.5 p-4" tint="cream">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-[#c79126]" />
            <p className="text-[0.82rem] leading-relaxed text-slate">
              Brand rules apply automatically. Colors, fonts, spacing, and layout cannot be changed here — those are
              protected to keep your site consistent and on-brand.
            </p>
          </Glass>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-3">
        <p className="text-[0.82rem] text-muted-foreground">
          Changes are queued for our team and go live only after review.
        </p>
        <Button className="bg-aqua text-cream hover:bg-aqua-bright" onClick={submit}>
          Submit for review
        </Button>
      </div>
    </div>
  );
}
