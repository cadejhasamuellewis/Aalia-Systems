import { useState } from "react";
import { Search, Clock, PlayCircle, GraduationCap } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Glass, Kicker } from "../../components/shared/glass";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import { Icon } from "../../components/shared/icon";
import { tutorials } from "../../data/mock";

const iconFor = (title: string) => {
  const t = title.toLowerCase();
  if (t.includes("image")) return "Image";
  if (t.includes("approve") || t.includes("file")) return "FileCheck";
  if (t.includes("report")) return "FileText";
  if (t.includes("seo")) return "Search";
  if (t.includes("domain")) return "Globe";
  if (t.includes("invoice") || t.includes("square")) return "Receipt";
  return "PlayCircle";
};

export default function Tutorials() {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<{ title: string; mins: number } | null>(null);

  const filtered = tutorials.filter((t) =>
    t.title.toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <Kicker>Learn</Kicker>
        <h1 className="text-[2rem] leading-tight text-charcoal">Tutorials</h1>
        <p className="max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
          Short, calm guides for getting the most out of your Aalia platform.
        </p>
      </div>

      {/* Search */}
      <div className="relative mt-6 max-w-sm">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search tutorials..."
          className="pl-9"
        />
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <Glass className="mt-6 flex flex-col items-center gap-2 p-12 text-center">
          <GraduationCap className="h-8 w-8 text-slate" />
          <div className="text-[0.95rem] text-charcoal">No tutorials match "{query}"</div>
          <p className="text-[0.85rem] text-muted-foreground">Try a different search term.</p>
        </Glass>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((t) => (
            <Glass key={t.title} className="group flex flex-col gap-4 p-6 transition-transform hover:-translate-y-0.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ice/70 text-aqua">
                <Icon name={iconFor(t.title)} className="h-5 w-5" />
              </span>
              <div className="flex-1">
                <h3 className="text-[1.05rem] leading-snug text-charcoal">{t.title}</h3>
                <div className="mt-2 flex items-center gap-1.5 font-mono text-[0.78rem] text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" /> {t.mins} min
                </div>
              </div>
              <Button
                variant="outline"
                className="mt-auto w-fit border-aqua/30 text-aqua hover:bg-white"
                onClick={() => setActive(t)}
              >
                <PlayCircle className="mr-1.5 h-4 w-4" /> Watch
              </Button>
            </Glass>
          ))}
        </div>
      )}

      <Dialog open={!!active} onOpenChange={(o) => !o && setActive(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{active?.title}</DialogTitle>
            <DialogDescription>
              {active?.mins} min · Tutorial preview
            </DialogDescription>
          </DialogHeader>
          <div className="flex aspect-video items-center justify-center rounded-xl bg-ice/60 text-aqua">
            <PlayCircle className="h-10 w-10" />
          </div>
          <p className="text-[0.88rem] leading-relaxed text-muted-foreground">
            Full tutorial content is a placeholder in this prototype. In the live build,
            this opens a short video or step-by-step walkthrough.
          </p>
        </DialogContent>
      </Dialog>
    </div>
  );
}
