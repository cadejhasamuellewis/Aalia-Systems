import { useState } from "react";
import { toast } from "sonner";
import { RefreshCw, ExternalLink, ShieldCheck, CheckCircle2, Clock } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { StatusPill, StatusRow, FeatureLabel } from "../../components/shared/status";
import { clientProfile } from "../../data/mock";

const maintenanceNotes = [
  { date: "Jul 21, 2026", note: "Monthly check complete. All pages loading, forms tested, SSL valid.", tone: "ok" as const },
  { date: "Jul 12, 2026", note: "Approved new primary logo file and refreshed favicon.", tone: "info" as const },
  { date: "Jul 1, 2026", note: "Broken link on Services page fixed. Mobile layout reviewed.", tone: "ok" as const },
  { date: "Jun 15, 2026", note: "Contact form spam filter tuned. No further issues observed.", tone: "info" as const },
];

export default function Website() {
  const [checking, setChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState("Jul 21, 2026 · 9:04 AM");

  function runCheck() {
    setChecking(true);
    setTimeout(() => {
      setChecking(false);
      setLastChecked("Jul 22, 2026 · just now");
      toast.success("Website check complete — everything looks healthy.");
    }, 1200);
  }

  return (
    <div className="p-5 sm:p-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[2rem] leading-tight text-charcoal">Website status</h1>
          <p className="mt-2 max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
            Live health, hosting, and maintenance history for your site.
          </p>
        </div>
        <a
          href={`https://${clientProfile.website}`}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 font-mono text-[0.82rem] text-aqua hover:text-aqua-bright"
        >
          {clientProfile.website} <ExternalLink className="h-3.5 w-3.5" />
        </a>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {/* Live status card */}
        <Glass className="flex flex-col p-6 lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="text-[1.15rem] text-charcoal">Live health</h2>
            <FeatureLabel state="Requires integration" />
          </div>
          <div className="mt-3">
            <StatusRow label="Website"><StatusPill tone="ok">Online</StatusPill></StatusRow>
            <StatusRow label="SSL certificate"><StatusPill tone="ok">Active · auto-renew</StatusPill></StatusRow>
            <StatusRow label="Domain"><StatusPill tone="ok">Connected</StatusPill></StatusRow>
            <StatusRow label="Mobile layout"><StatusPill tone="ok">Passing</StatusPill></StatusRow>
            <StatusRow label="Forms"><StatusPill tone="ok">Tested</StatusPill></StatusRow>
            <StatusRow label="Last checked">
              <span className="font-mono text-[0.78rem] text-charcoal">{lastChecked}</span>
            </StatusRow>
          </div>
          <Button
            onClick={runCheck}
            disabled={checking}
            className="mt-4 w-fit bg-aqua text-cream hover:bg-aqua-bright"
          >
            <RefreshCw className={`mr-1.5 h-4 w-4 ${checking ? "animate-spin" : ""}`} />
            {checking ? "Running check…" : "Run check"}
          </Button>
        </Glass>

        {/* Hosting note */}
        <Glass className="flex flex-col gap-3 p-6" tint="ice">
          <h2 className="text-[1.15rem] text-charcoal">Hosting</h2>
          <StatusRow label="Provider">
            <span className="font-mono text-[0.82rem] text-charcoal">Managed by Aalia</span>
          </StatusRow>
          <StatusRow label="Uptime (30d)">
            <span className="font-mono text-[0.82rem] text-charcoal">99.98%</span>
          </StatusRow>
          <StatusRow label="Backups">
            <StatusPill tone="ok" dot={false}>Nightly</StatusPill>
          </StatusRow>
          <div className="mt-2 flex items-start gap-2 rounded-xl border border-white/60 bg-white/60 p-3">
            <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-aqua" />
            <p className="text-[0.78rem] leading-relaxed text-slate">
              Hosting and code are managed for you. Clients never need code access — your workspace stays isolated.
            </p>
          </div>
        </Glass>
      </div>

      {/* Maintenance timeline */}
      <Glass className="mt-4 p-6">
        <h2 className="text-[1.15rem] text-charcoal">Maintenance notes</h2>
        <p className="mt-1 text-[0.85rem] text-muted-foreground">A running log of care checks and fixes.</p>
        <ol className="mt-5 space-y-5">
          {maintenanceNotes.map((n, i) => (
            <li key={i} className="relative flex gap-4 pl-1">
              <span className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-ice/70 text-aqua">
                {n.tone === "ok" ? <CheckCircle2 className="h-4 w-4" /> : <Clock className="h-4 w-4" />}
              </span>
              <div className="flex-1 border-b border-border/50 pb-5 last:border-0">
                <div className="font-mono text-[0.7rem] uppercase tracking-wide text-copper">{n.date}</div>
                <p className="mt-1 text-[0.9rem] leading-relaxed text-charcoal">{n.note}</p>
              </div>
            </li>
          ))}
        </ol>
      </Glass>
    </div>
  );
}
