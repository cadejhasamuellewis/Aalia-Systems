import { Search, ArrowUpRight, BookOpen } from "lucide-react";
import { Glass, Kicker } from "../../components/shared/glass";
import { Icon } from "../../components/shared/icon";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "../../components/ui/accordion";
import { seoResources } from "../../data/mock";

const iconFor = (title: string) => {
  const t = title.toLowerCase();
  if (t.includes("business profile")) return "MapPin";
  if (t.includes("title")) return "Type";
  if (t.includes("meta")) return "FileText";
  if (t.includes("alt")) return "Image";
  if (t.includes("local")) return "Map";
  if (t.includes("speed")) return "Gauge";
  if (t.includes("accessib")) return "Accessibility";
  if (t.includes("fresh")) return "RefreshCw";
  return "Search";
};

const faq = [
  { q: "How long until SEO changes show results?", a: "Search engines re-crawl over days to weeks. Meaningful ranking shifts usually take one to three months of consistent, quality content." },
  { q: "Do I need to pay Google to rank?", a: "No. Organic (unpaid) search rankings come from relevant content, clear structure, and a fast, accessible site. Ads are separate and optional." },
  { q: "What matters most for a small local business?", a: "A complete Google Business Profile, consistent name/address/phone across the web, clear page titles, and genuine reviews." },
];

export default function Seo() {
  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <Kicker>Grow</Kicker>
        <h1 className="text-[2rem] leading-tight text-charcoal">SEO resources</h1>
        <p className="max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
          Plain-language guidance to help more of the right people find your website.
        </p>
      </div>

      {/* Top note */}
      <Glass tint="cream" className="mt-6 flex items-start gap-3 p-5">
        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/70 text-copper">
          <BookOpen className="h-4 w-4" />
        </span>
        <p className="text-[0.9rem] leading-relaxed text-muted-foreground">
          These explanations are illustrative and educational. SEO guidance is kept
          current, and in the live build each resource should cite trusted sources such
          as Google Search Central and the W3C.
        </p>
      </Glass>

      {/* Cards */}
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {seoResources.map((r) => (
          <Glass key={r.title} className="group flex flex-col gap-3 p-6 transition-transform hover:-translate-y-0.5">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-ice/70 text-aqua">
              <Icon name={iconFor(r.title)} className="h-5 w-5" />
            </span>
            <h3 className="text-[1.05rem] text-charcoal">{r.title}</h3>
            <p className="flex-1 text-[0.88rem] leading-relaxed text-muted-foreground">{r.body}</p>
            <button className="flex w-fit items-center gap-1 text-[0.82rem] text-aqua transition-colors hover:text-aqua-bright">
              Learn more <ArrowUpRight className="h-3.5 w-3.5" />
            </button>
          </Glass>
        ))}
      </div>

      {/* FAQ accordion */}
      <div className="mt-10">
        <div className="flex items-center gap-2">
          <Search className="h-4 w-4 text-aqua" />
          <h2 className="text-[1.3rem] text-charcoal">Common SEO questions</h2>
        </div>
        <Glass className="mt-4 px-6 py-2">
          <Accordion type="single" collapsible>
            {faq.map((f, i) => (
              <AccordionItem key={i} value={`faq-${i}`}>
                <AccordionTrigger className="text-left text-[0.95rem] text-charcoal">{f.q}</AccordionTrigger>
                <AccordionContent className="text-[0.88rem] leading-relaxed text-muted-foreground">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Glass>
      </div>
    </div>
  );
}
