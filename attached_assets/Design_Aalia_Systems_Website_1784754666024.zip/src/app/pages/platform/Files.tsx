import { useState } from "react";
import { toast } from "sonner";
import { UploadCloud, Check, RotateCcw, FolderOpen, MessageSquare } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { StatusPill } from "../../components/shared/status";
import { Icon } from "../../components/shared/icon";
import { cn } from "../../components/ui/utils";
import { files as seedFiles } from "../../data/mock";

type FileItem = (typeof seedFiles)[number];

const statusTone: Record<string, "ok" | "info" | "warn" | "muted" | "aqua"> = {
  Approved: "ok",
  "In review": "warn",
  "Changes requested": "info",
};

const kindIcon: Record<string, string> = {
  Logo: "Sparkles",
  Image: "Image",
  "Brand file": "Palette",
  "Website copy": "FileText",
  Document: "FileText",
};

const filters = ["All", "In review", "Approved", "Changes requested"];

export default function Files() {
  const [items, setItems] = useState<FileItem[]>(seedFiles);
  const [filter, setFilter] = useState("All");
  const [selected, setSelected] = useState<string | null>(seedFiles[1]?.id ?? null);

  const shown = filter === "All" ? items : items.filter((i) => i.status === filter);
  const selectedFile = items.find((f) => f.id === selected) ?? null;

  function setStatus(id: string, status: string, msg: string) {
    setItems((prev) => prev.map((f) => (f.id === id ? { ...f, status } : f)));
    toast.success(msg);
  }

  return (
    <div className="p-5 sm:p-8">
      <div>
        <h1 className="text-[2rem] leading-tight text-charcoal">Files + approvals</h1>
        <p className="mt-2 max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
          Review, approve, and share brand files. Everything is scoped to your workspace only.
        </p>
      </div>

      {/* Upload dropzone */}
      <Glass className="mt-6 p-4">
        <label className="flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-xl border border-dashed border-aqua/40 bg-ice/40 px-4 py-7 text-center transition-colors hover:bg-ice/60">
          <UploadCloud className="h-6 w-6 text-aqua" />
          <span className="text-[0.9rem] text-charcoal">Drag files here or click to upload</span>
          <span className="font-mono text-[0.68rem] text-muted-foreground">Logos, images, brand files, copy · up to 50MB</span>
          <input type="file" multiple className="hidden" />
        </label>
      </Glass>

      {/* Filters */}
      <div className="mt-5 flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "rounded-full border px-3 py-1.5 font-mono text-[0.72rem] tracking-wide transition-colors",
              filter === f
                ? "border-aqua bg-aqua text-cream"
                : "border-white/60 bg-white/50 text-slate hover:bg-white",
            )}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="mt-5 grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        {/* File list */}
        <div className="space-y-2.5">
          {shown.length === 0 ? (
            <Glass className="flex flex-col items-center gap-3 p-12 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-ice/70 text-aqua">
                <FolderOpen className="h-5 w-5" />
              </span>
              <p className="text-[0.95rem] text-charcoal">No files in this view</p>
              <p className="max-w-sm text-[0.85rem] text-muted-foreground">Upload a file above to get started.</p>
            </Glass>
          ) : (
            shown.map((f) => (
              <Glass
                key={f.id}
                className={cn(
                  "flex flex-wrap items-center gap-3 p-4 transition-colors",
                  selected === f.id && "ring-2 ring-aqua/40",
                )}
              >
                <button onClick={() => setSelected(f.id)} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-ice/70 text-aqua">
                    <Icon name={kindIcon[f.kind] ?? "File"} className="h-4 w-4" />
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate font-mono text-[0.85rem] text-charcoal">{f.name}</span>
                    <span className="block font-mono text-[0.68rem] text-muted-foreground">
                      {f.kind} · {f.by} · {f.date}
                    </span>
                  </span>
                </button>
                <StatusPill tone={statusTone[f.status] ?? "muted"} dot={false}>{f.status}</StatusPill>
                {f.status === "In review" && (
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="bg-aqua text-cream hover:bg-aqua-bright"
                      onClick={() => setStatus(f.id, "Approved", `Approved ${f.name}.`)}
                    >
                      <Check className="mr-1 h-3.5 w-3.5" /> Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-aqua/30 text-aqua hover:bg-white"
                      onClick={() => setStatus(f.id, "Changes requested", `Change request sent for ${f.name}.`)}
                    >
                      <RotateCcw className="mr-1 h-3.5 w-3.5" /> Request changes
                    </Button>
                  </div>
                )}
              </Glass>
            ))
          )}
        </div>

        {/* Comments / detail panel */}
        <Glass className="flex flex-col p-6" tint="ice">
          <div className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-aqua" />
            <h2 className="text-[1.05rem] text-charcoal">Comments</h2>
          </div>
          {selectedFile ? (
            <>
              <p className="mt-1 font-mono text-[0.78rem] text-muted-foreground">{selectedFile.name}</p>
              <div className="mt-4 space-y-3">
                <div className="rounded-xl border border-white/60 bg-white/60 p-3">
                  <div className="font-mono text-[0.68rem] uppercase tracking-wide text-copper">Aalia · Jul 20</div>
                  <p className="mt-1 text-[0.85rem] text-slate">Uploaded for your review — let us know if the crop works.</p>
                </div>
                <div className="rounded-xl border border-white/60 bg-white/60 p-3">
                  <div className="font-mono text-[0.68rem] uppercase tracking-wide text-copper">You · Jul 20</div>
                  <p className="mt-1 text-[0.85rem] text-slate">Looks great — approving shortly.</p>
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                <input
                  className="flex-1 rounded-lg border border-white/60 bg-white/70 px-3 py-2 text-[0.85rem] text-charcoal placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-aqua/30"
                  placeholder="Add a comment…"
                />
                <Button
                  size="sm"
                  className="bg-aqua text-cream hover:bg-aqua-bright"
                  onClick={() => toast.success("Comment added.")}
                >
                  Send
                </Button>
              </div>
            </>
          ) : (
            <p className="mt-3 text-[0.85rem] text-muted-foreground">Select a file to view its comments.</p>
          )}
        </Glass>
      </div>
    </div>
  );
}
