import { useState } from "react";
import { UserPlus, Building2, Users, Bell, Receipt, Globe, ShieldCheck } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Switch } from "../../components/ui/switch";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "../../components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import { Glass, Kicker } from "../../components/shared/glass";
import { StatusPill } from "../../components/shared/status";
import { clientProfile } from "../../data/mock";
import { toast } from "sonner";

const authorizedUsers = [
  { name: "Naomi Bright", email: "naomi@marigoldco.studio", role: "Client Owner", perms: "Full access · billing · users · approvals" },
  { name: "Priya Chandra", email: "priya@marigoldco.studio", role: "Client Editor", perms: "Requests · brand-safe edits · files" },
  { name: "Jordan Lee", email: "jordan@marigoldco.studio", role: "View only", perms: "Read-only dashboard access" },
];

const roleTone = (role: string) =>
  role === "Client Owner" ? "aqua" : role === "Client Editor" ? "info" : "muted";

export default function Settings() {
  const [business, setBusiness] = useState(clientProfile.business);
  const [contactName, setContactName] = useState("Naomi Bright");
  const [contactEmail, setContactEmail] = useState("naomi@marigoldco.studio");
  const [contactPhone, setContactPhone] = useState("(555) 012-8834");
  const [billingEmail, setBillingEmail] = useState("billing@marigoldco.studio");

  const [notifRequests, setNotifRequests] = useState(true);
  const [notifInvoices, setNotifInvoices] = useState(true);
  const [notifCare, setNotifCare] = useState(false);

  const save = (label: string) => toast.success(`${label} saved`);

  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <Kicker>Account</Kicker>
        <h1 className="text-[2rem] leading-tight text-charcoal">Settings</h1>
        <p className="max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
          Manage your business profile, team access, notifications, and privacy.
        </p>
      </div>

      <Tabs defaultValue="profile" className="mt-6">
        <TabsList className="flex-wrap">
          <TabsTrigger value="profile">Business profile</TabsTrigger>
          <TabsTrigger value="users">Authorized users</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="privacy">Access & privacy</TabsTrigger>
        </TabsList>

        {/* Business profile */}
        <TabsContent value="profile" className="mt-5">
          <Glass className="p-6">
            <div className="flex items-center gap-2">
              <Building2 className="h-4 w-4 text-aqua" />
              <h2 className="text-[1.15rem] text-charcoal">Business profile</h2>
            </div>
            <form
              className="mt-5 grid gap-4 sm:grid-cols-2"
              onSubmit={(e) => { e.preventDefault(); save("Business profile"); }}
            >
              <div className="grid gap-1.5 sm:col-span-2">
                <Label htmlFor="biz">Business name</Label>
                <Input id="biz" value={business} onChange={(e) => setBusiness(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="cname">Primary contact</Label>
                <Input id="cname" value={contactName} onChange={(e) => setContactName(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="cemail">Contact email</Label>
                <Input id="cemail" type="email" value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="cphone">Contact phone</Label>
                <Input id="cphone" value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="site">Website</Label>
                <Input id="site" value={clientProfile.website} readOnly className="bg-muted/40" />
              </div>
              <div className="sm:col-span-2">
                <Button type="submit" className="bg-aqua text-cream hover:bg-aqua-bright">Save changes</Button>
              </div>
            </form>
          </Glass>

          <Glass className="mt-4 p-6">
            <div className="flex items-center gap-2">
              <Receipt className="h-4 w-4 text-aqua" />
              <h2 className="text-[1.15rem] text-charcoal">Billing contact</h2>
            </div>
            <form
              className="mt-5 grid max-w-md gap-4"
              onSubmit={(e) => { e.preventDefault(); save("Billing contact"); }}
            >
              <div className="grid gap-1.5">
                <Label htmlFor="bemail">Billing email</Label>
                <Input id="bemail" type="email" value={billingEmail} onChange={(e) => setBillingEmail(e.target.value)} />
              </div>
              <p className="text-[0.82rem] text-muted-foreground">
                Invoices and receipts are sent here. Payments are processed by Square — no
                card data is stored by Aalia.
              </p>
              <Button type="submit" className="w-fit bg-aqua text-cream hover:bg-aqua-bright">Save billing contact</Button>
            </form>
          </Glass>
        </TabsContent>

        {/* Authorized users */}
        <TabsContent value="users" className="mt-5">
          <Glass className="overflow-hidden p-0">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/50 p-5">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-aqua" />
                <h2 className="text-[1.15rem] text-charcoal">Authorized users</h2>
              </div>
              <Button
                className="bg-aqua text-cream hover:bg-aqua-bright"
                onClick={() => toast.success("Invite sent")}
              >
                <UserPlus className="mr-1.5 h-4 w-4" /> Invite user
              </Button>
            </div>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">User</TableHead>
                    <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Role</TableHead>
                    <TableHead className="font-mono text-[0.72rem] uppercase tracking-wide">Permissions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {authorizedUsers.map((u) => (
                    <TableRow key={u.email}>
                      <TableCell>
                        <div className="text-[0.9rem] text-charcoal">{u.name}</div>
                        <div className="font-mono text-[0.72rem] text-muted-foreground">{u.email}</div>
                      </TableCell>
                      <TableCell>
                        <StatusPill tone={roleTone(u.role)} dot={false}>{u.role}</StatusPill>
                      </TableCell>
                      <TableCell className="text-[0.82rem] text-slate">{u.perms}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="border-t border-white/50 p-5 text-[0.82rem] leading-relaxed text-muted-foreground">
              <span className="text-charcoal">Role model.</span> Client Owner manages billing,
              users, and final approvals. Client Editor can submit requests and make
              brand-safe edits but cannot manage billing or users. View-only users can see
              the dashboard without making changes.
            </div>
          </Glass>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="mt-5">
          <Glass className="p-6">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-aqua" />
              <h2 className="text-[1.15rem] text-charcoal">Notification preferences</h2>
            </div>
            <div className="mt-5 divide-y divide-border/60">
              {[
                { label: "Request updates", desc: "Email me when a request changes status.", val: notifRequests, set: setNotifRequests },
                { label: "Invoices", desc: "Email me when a new invoice is issued.", val: notifInvoices, set: setNotifInvoices },
                { label: "Monthly reports", desc: "Email me monthly website reports.", val: notifCare, set: setNotifCare },
              ].map((n) => (
                <div key={n.label} className="flex items-center justify-between gap-4 py-4">
                  <div>
                    <div className="text-[0.92rem] text-charcoal">{n.label}</div>
                    <div className="text-[0.82rem] text-muted-foreground">{n.desc}</div>
                  </div>
                  <Switch checked={n.val} onCheckedChange={n.set} />
                </div>
              ))}
            </div>
            <Button className="mt-5 bg-aqua text-cream hover:bg-aqua-bright" onClick={() => save("Notification preferences")}>
              Save preferences
            </Button>
          </Glass>
        </TabsContent>

        {/* Access & privacy */}
        <TabsContent value="privacy" className="mt-5 grid gap-4">
          <Glass className="p-6">
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-aqua" />
              <h2 className="text-[1.15rem] text-charcoal">Website access notes</h2>
            </div>
            <p className="mt-3 text-[0.9rem] leading-relaxed text-muted-foreground">
              Aalia coordinates your website through approved workflows. You request
              updates and make brand-safe edits here — you do not need code, hosting, or
              domain credentials to work with your site. Aalia manages provider records
              on your behalf and shares status openly.
            </p>
          </Glass>

          <Glass tint="ice" className="p-6">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-aqua" />
              <h2 className="text-[1.15rem] text-charcoal">Data & privacy</h2>
            </div>
            <ul className="mt-4 grid gap-3">
              {[
                "Your client data is isolated to your workspace and not shared with other clients.",
                "You are not given raw code or hosting-credential access; Aalia manages that securely.",
                "No protected health information (PHI) is stored in this platform.",
                "Payments run through Square's hosted, tokenized flow — no card data is stored by Aalia.",
              ].map((t) => (
                <li key={t} className="flex items-start gap-2.5 text-[0.88rem] text-slate">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-aqua" /> {t}
                </li>
              ))}
            </ul>
          </Glass>
        </TabsContent>
      </Tabs>
    </div>
  );
}
