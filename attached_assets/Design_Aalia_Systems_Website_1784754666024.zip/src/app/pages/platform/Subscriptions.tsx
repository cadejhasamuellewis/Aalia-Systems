import { useState } from "react";
import { Check, RefreshCw, CreditCard, CalendarClock, Lock } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass, Kicker } from "../../components/shared/glass";
import { StatusPill, FeatureLabel, StatusRow } from "../../components/shared/status";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import { subscription, invoices } from "../../data/mock";
import { toast } from "sonner";

export default function Subscriptions() {
  const [confirmOpen, setConfirmOpen] = useState(false);

  const submitRequest = () => {
    setConfirmOpen(false);
    toast.success("Change request sent — Aalia will confirm by email.");
  };

  return (
    <div className="p-5 sm:p-8">
      {/* Header */}
      <div className="flex flex-col gap-3">
        <Kicker>Billing</Kicker>
        <div className="flex flex-wrap items-center gap-3">
          <h1 className="text-[2rem] leading-tight text-charcoal">Subscription</h1>
          <FeatureLabel state="Requires payment processor setup" />
        </div>
        <p className="max-w-xl text-[1rem] leading-relaxed text-muted-foreground">
          Your recurring plan and what it includes. Payment is handled by Square.
        </p>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        {/* Plan card */}
        <Glass className="flex flex-col gap-5 p-6">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <div className="text-[0.8rem] font-mono uppercase tracking-wide text-copper">Current plan</div>
              <h2 className="mt-1 text-[1.4rem] text-charcoal">{subscription.plan}</h2>
              <div className="mt-1 font-mono text-[1.1rem] text-aqua">{subscription.amount}</div>
            </div>
            <StatusPill tone="aqua">{subscription.status}</StatusPill>
          </div>

          <div className="rounded-xl border border-white/60 bg-white/50 p-4">
            <StatusRow label="Renews">
              <span className="font-mono text-[0.85rem] text-charcoal">{subscription.renews}</span>
            </StatusRow>
            <StatusRow label="Next invoice">
              <span className="font-mono text-[0.85rem] text-charcoal">{subscription.nextInvoice}</span>
            </StatusRow>
            <StatusRow label="Billing">
              <span className="font-mono text-[0.85rem] text-slate">Square (recurring)</span>
            </StatusRow>
          </div>

          <div>
            <div className="text-[0.85rem] text-charcoal">Included services</div>
            <ul className="mt-3 grid gap-2 sm:grid-cols-2">
              {subscription.included.map((s) => (
                <li key={s} className="flex items-center gap-2 text-[0.88rem] text-slate">
                  <Check className="h-4 w-4 shrink-0 text-aqua" /> {s}
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-wrap gap-3 pt-1">
            <Button
              className="bg-aqua text-cream hover:bg-aqua-bright"
              onClick={() => toast.success("Redirecting to Square to manage your subscription")}
            >
              <CreditCard className="mr-1.5 h-4 w-4" /> Manage subscription
            </Button>
            <Button
              variant="outline"
              className="border-aqua/30 text-aqua hover:bg-white"
              onClick={() => setConfirmOpen(true)}
            >
              <RefreshCw className="mr-1.5 h-4 w-4" /> Cancel / change request
            </Button>
          </div>
        </Glass>

        <div className="flex flex-col gap-4">
          {/* Payment note */}
          <Glass tint="ice" className="flex items-start gap-3 p-5">
            <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/70 text-aqua">
              <Lock className="h-4 w-4" />
            </span>
            <div>
              <div className="text-[0.95rem] text-charcoal">Payment handled by Square</div>
              <p className="mt-1 text-[0.85rem] leading-relaxed text-muted-foreground">
                Recurring billing runs through Square's secure, tokenized flow. Aalia does
                not store card data.
              </p>
            </div>
          </Glass>

          {/* Billing history summary */}
          <Glass className="p-5">
            <div className="flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-aqua" />
              <h3 className="text-[1rem] text-charcoal">Recent billing</h3>
            </div>
            <div className="mt-3">
              {invoices.slice(0, 4).map((inv) => (
                <StatusRow key={inv.id} label={`${inv.id} · ${inv.due}`}>
                  <span className="flex items-center gap-2">
                    <span className="font-mono text-[0.82rem] text-charcoal">{inv.amount}</span>
                    <StatusPill tone={inv.status === "Paid" ? "ok" : "warn"} dot={false}>{inv.status}</StatusPill>
                  </span>
                </StatusRow>
              ))}
            </div>
          </Glass>
        </div>
      </div>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Request a plan change or cancellation</DialogTitle>
            <DialogDescription>
              This sends a request to Aalia. Nothing changes immediately — a team member
              will confirm details and next steps by email before any billing changes.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" className="border-aqua/30 text-aqua hover:bg-white" onClick={() => setConfirmOpen(false)}>
              Not now
            </Button>
            <Button className="bg-aqua text-cream hover:bg-aqua-bright" onClick={submitRequest}>
              Send request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
