import { Glass } from "../../components/shared/glass";
import { Section } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { FeatureLabel } from "../../components/shared/status";

const sections = [
  {
    h: "Scope of services",
    p: "Aalia Systems provides website design, redesign, monthly managed support, brand and document support, coordination services, and access to a client platform. The specific scope of any engagement is defined in your written quote or agreement.",
  },
  {
    h: "Subscriptions & billing",
    p: "Monthly support and platform subscriptions are billed on a recurring basis through our payment processor (Square). By subscribing, you authorize recurring charges until the subscription is cancelled. Prices shown on the site are placeholders and are confirmed in your quote.",
  },
  {
    h: "Cancellation",
    p: "You may cancel a subscription at any time; cancellation takes effect at the end of the current billing period. One-time projects are governed by the terms in their individual agreements.",
  },
  {
    h: "Brand-safe edit boundaries",
    p: "Where clients can make edits, changes are limited to approved content areas. Layout, structure, and brand rules remain protected to keep your site consistent and functional.",
  },
  {
    h: "No code access",
    p: "The client platform does not provide access to underlying code. This protects the integrity, security, and stability of your website.",
  },
  {
    h: "Limitations",
    p: "We provide security-minded maintenance and basic website checks. We do not guarantee absolute security, uninterrupted uptime, or protection against all threats. Monthly support is not a full cybersecurity service or a security certification.",
  },
  {
    h: "Healthcare boundary",
    p: "Aalia Systems is not an EHR and does not store or process protected health information (PHI). For healthcare-adjacent clients, PHI remains within your own approved EHR. We are not HIPAA compliant unless formally verified in writing for a specific engagement.",
  },
  {
    h: "Governing terms",
    p: "These terms, together with your individual agreement, govern our working relationship. If any conflict arises, the signed agreement controls. Continued use of our services constitutes acceptance of these terms.",
  },
];

export default function Terms() {
  return (
    <>
      <PageHero kicker="Legal" title="Service Terms" support="The terms that govern working with Aalia Systems." />
      <Section>
        <Glass className="mx-auto max-w-3xl p-8 sm:p-12">
          <div className="mb-6 flex flex-wrap items-center gap-3">
            <FeatureLabel state="Requires legal review" />
            <span className="font-mono text-[0.7rem] uppercase tracking-[0.14em] text-muted-foreground">Last updated: July 2026</span>
          </div>
          <p className="text-[0.92rem] leading-relaxed text-muted-foreground">
            These terms are a working draft and should be reviewed by legal counsel
            before publication.
          </p>
          <div className="mt-8 space-y-8">
            {sections.map((s) => (
              <div key={s.h}>
                <h2 className="text-[1.2rem] text-charcoal">{s.h}</h2>
                <p className="mt-2 text-[0.92rem] leading-relaxed text-slate">{s.p}</p>
              </div>
            ))}
          </div>
        </Glass>
      </Section>
    </>
  );
}
