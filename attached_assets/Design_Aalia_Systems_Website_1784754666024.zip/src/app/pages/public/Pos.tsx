import { Link } from "react-router";
import { Check, X, ShieldAlert } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";

const canHelp = [
  "POS setup coordination with your chosen provider",
  "Product and service organization",
  "Menu and service list setup",
  "Basic workflow planning",
  "Vendor support and coordination",
  "Staff training documentation",
  "Website and POS coordination",
];

const dontDo = [
  "We are not a certified reseller of any POS platform",
  "We do not provide financial, accounting, or tax advice",
  "We do not process or hold payments on your behalf",
  "We do not guarantee provider pricing, terms, or availability",
];

export default function Pos() {
  return (
    <>
      <PageHero
        kicker="POS + business systems"
        title="Help getting your business systems organized."
        support="Coordination, setup support, and documentation so your point-of-sale and workflows work the way your business does."
      />

      <Section>
        <Glass className="p-8 lg:p-12">
          <SectionHeading kicker="How we help" title="Aalia can help with:" />
          <ul className="mt-7 grid gap-3 sm:grid-cols-2">
            {canHelp.map((c) => (
              <li key={c} className="flex items-start gap-3 rounded-xl border border-white/60 bg-white/60 p-4">
                <Check className="mt-0.5 h-4 w-4 shrink-0 text-aqua" />
                <span className="text-[0.9rem] leading-snug text-charcoal">{c}</span>
              </li>
            ))}
          </ul>
        </Glass>
      </Section>

      <Section>
        <Glass className="p-8 lg:p-12" tint="cream">
          <SectionHeading kicker="Clear boundaries" title="What we don't do." support="We're careful to stay within our lane. These are important limits on our POS support." />
          <ul className="mt-7 grid gap-3 sm:grid-cols-2">
            {dontDo.map((d) => (
              <li key={d} className="flex items-start gap-3 rounded-xl border border-border/70 bg-white/50 p-4">
                <X className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                <span className="text-[0.9rem] leading-snug text-muted-foreground">{d}</span>
              </li>
            ))}
          </ul>
        </Glass>
      </Section>

      <Section>
        <Glass className="flex flex-col gap-4 border-copper/20 p-8 lg:p-10" tint="cream">
          <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-copper/15 text-copper">
            <ShieldAlert className="h-5 w-5" />
          </span>
          <h3 className="text-[1.2rem] text-charcoal">Healthcare-adjacent boundary note</h3>
          <p className="max-w-2xl text-[0.92rem] leading-relaxed text-slate">
            For healthcare-adjacent businesses, protected health information (PHI)
            remains in your own approved EHR system at all times. Aalia Systems is
            not an EHR, does not store or process PHI, and is not HIPAA compliant
            unless formally verified in writing for a specific engagement. Our work
            stays limited to public-facing websites, coordination, and documentation.
          </p>
        </Glass>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">Let's get your systems organized.</h2>
          <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
            <Link to="/start">Start a project</Link>
          </Button>
        </Glass>
      </Section>
    </>
  );
}
