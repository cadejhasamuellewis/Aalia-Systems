import { useState } from "react";
import { Link } from "react-router";
import { Check } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass, Chip } from "../../components/shared/glass";
import { Section } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { mockSites } from "../../data/mock";

const categories = ["All", ...Array.from(new Set(mockSites.map((s) => s.type)))];

export default function Examples() {
  const [active, setActive] = useState("All");
  const shown = active === "All" ? mockSites : mockSites.filter((s) => s.type === active);

  return (
    <>
      <PageHero
        kicker="Website examples"
        title="Concept websites across industries."
        support="These are illustrative concepts to show range and possibility — not presented as real client work."
      />

      <Section>
        <div className="mb-8 flex flex-wrap gap-2">
          {categories.map((c) => (
            <button key={c} type="button" onClick={() => setActive(c)}>
              <Chip
                className={
                  active === c
                    ? "border-aqua/40 bg-aqua/12 text-aqua"
                    : "cursor-pointer hover:bg-white"
                }
              >
                {c}
              </Chip>
            </button>
          ))}
        </div>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((s) => (
            <Glass key={s.id} className="group flex flex-col overflow-hidden p-0">
              <div className="relative h-44 overflow-hidden bg-ice">
                <img
                  src={`https://images.unsplash.com/${s.img}?w=640&h=400&fit=crop&auto=format`}
                  alt={`${s.type} mock website concept`}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute left-3 top-3 rounded-md bg-charcoal/70 px-2 py-1 font-mono text-[0.6rem] uppercase tracking-wide text-cream backdrop-blur-sm">
                  Mock website concept
                </span>
              </div>
              <div className="flex flex-1 flex-col gap-4 p-5">
                <h3 className="text-[1.05rem] text-charcoal">{s.type}</h3>
                <div>
                  <div className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">Included pages</div>
                  <p className="mt-1 text-[0.85rem] text-slate">{s.pages.join(" · ")}</p>
                </div>
                <div>
                  <div className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">Suggested features</div>
                  <ul className="mt-1.5 space-y-1">
                    {s.features.map((f) => (
                      <li key={f} className="flex items-center gap-2 text-[0.85rem] text-slate">
                        <Check className="h-3.5 w-3.5 text-aqua" /> {f}
                      </li>
                    ))}
                  </ul>
                </div>
                <Button asChild className="mt-auto bg-aqua text-cream hover:bg-aqua-bright">
                  <Link to="/start">Build something like this</Link>
                </Button>
              </div>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">Ready to build your own?</h2>
          <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
            <Link to="/start">Start a project</Link>
          </Button>
        </Glass>
      </Section>
    </>
  );
}
