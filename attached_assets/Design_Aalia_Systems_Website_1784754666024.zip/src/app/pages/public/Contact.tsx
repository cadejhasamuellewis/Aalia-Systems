import { useState } from "react";
import { toast } from "sonner";
import { Mail, Clock, MessageSquare, AlertTriangle, CheckCircle2 } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Label } from "../../components/ui/label";
import { Checkbox } from "../../components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "../../components/ui/select";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";

const reasons = ["New project inquiry", "Current client support", "General question"];

export default function Contact() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [reason, setReason] = useState("");
  const [message, setMessage] = useState("");
  const [consent, setConsent] = useState(false);
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, boolean>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const err: Record<string, boolean> = {};
    if (!name.trim()) err.name = true;
    if (!email.trim()) err.email = true;
    if (!reason) err.reason = true;
    if (!message.trim()) err.message = true;
    if (!consent) err.consent = true;
    setErrors(err);
    if (Object.keys(err).length) {
      toast.error("Please complete the required fields.");
      return;
    }
    setSent(true);
    toast.success("Message sent. We'll reply within 1–2 business days.");
  };

  return (
    <>
      <PageHero
        kicker="Contact"
        title="Let's talk about your project."
        support="Whether you're starting fresh or need support with an existing site, we're glad to help."
      />

      <Section>
        <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
          <Glass className="p-6 sm:p-9">
            {sent ? (
              <div className="flex flex-col items-center gap-4 py-12 text-center">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-aqua text-cream">
                  <CheckCircle2 className="h-7 w-7" />
                </span>
                <h2 className="text-[1.6rem] text-charcoal">Message sent</h2>
                <p className="max-w-sm text-[0.92rem] text-muted-foreground">
                  Thanks, {name}. We've received your {reason.toLowerCase()} and will reply within 1–2 business days.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                <SectionHeading kicker="Send a message" title="How can we help?" />
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="flex flex-col gap-2">
                    <Label className="text-[0.85rem] text-charcoal">Your name <span className="text-copper">*</span></Label>
                    <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" />
                    {errors.name && <span className="text-[0.78rem] text-destructive">Required.</span>}
                  </div>
                  <div className="flex flex-col gap-2">
                    <Label className="text-[0.85rem] text-charcoal">Email <span className="text-copper">*</span></Label>
                    <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@business.com" />
                    {errors.email && <span className="text-[0.78rem] text-destructive">Required.</span>}
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-[0.85rem] text-charcoal">Reason for contact <span className="text-copper">*</span></Label>
                  <Select value={reason} onValueChange={setReason}>
                    <SelectTrigger><SelectValue placeholder="Select a reason" /></SelectTrigger>
                    <SelectContent>
                      {reasons.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  {errors.reason && <span className="text-[0.78rem] text-destructive">Required.</span>}
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-[0.85rem] text-charcoal">Message <span className="text-copper">*</span></Label>
                  <Textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={5} placeholder="Tell us a little about what you need." />
                  {errors.message && <span className="text-[0.78rem] text-destructive">Required.</span>}
                </div>
                <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 ${errors.consent ? "border-destructive/50 bg-destructive/5" : "border-white/60 bg-white/60"}`}>
                  <Checkbox checked={consent} onCheckedChange={(v) => setConsent(v === true)} className="mt-0.5" />
                  <span className="text-[0.85rem] leading-relaxed text-slate">I consent to being contacted about my message. <span className="text-copper">*</span></span>
                </label>
                <Button type="submit" className="h-11 w-fit bg-aqua px-6 text-cream hover:bg-aqua-bright">Send message</Button>
              </form>
            )}
          </Glass>

          <div className="flex flex-col gap-4">
            <Glass className="flex items-start gap-3 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ice/70 text-aqua"><Clock className="h-5 w-5" /></span>
              <div>
                <div className="text-[0.95rem] text-charcoal">Response time</div>
                <p className="mt-1 text-[0.84rem] text-muted-foreground">We reply within 1–2 business days.</p>
              </div>
            </Glass>
            <Glass className="flex items-start gap-3 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ice/70 text-aqua"><Mail className="h-5 w-5" /></span>
              <div>
                <div className="text-[0.95rem] text-charcoal">Email</div>
                <p className="mt-1 font-mono text-[0.82rem] text-slate">hello@aaliasystems.com</p>
              </div>
            </Glass>
            <Glass className="flex items-start gap-3 p-5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ice/70 text-aqua"><MessageSquare className="h-5 w-5" /></span>
              <div>
                <div className="text-[0.95rem] text-charcoal">Current clients</div>
                <p className="mt-1 text-[0.84rem] text-muted-foreground">Use your client platform to submit support requests and track status.</p>
              </div>
            </Glass>
            <Glass className="flex items-start gap-3 p-5 border-copper/20" tint="cream">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-copper/15 text-copper"><AlertTriangle className="h-5 w-5" /></span>
              <div>
                <div className="text-[0.95rem] text-charcoal">Not for emergencies</div>
                <p className="mt-1 text-[0.84rem] text-muted-foreground">This form is not monitored for urgent issues. Please don't share sensitive or emergency information here.</p>
              </div>
            </Glass>
          </div>
        </div>
      </Section>
    </>
  );
}
