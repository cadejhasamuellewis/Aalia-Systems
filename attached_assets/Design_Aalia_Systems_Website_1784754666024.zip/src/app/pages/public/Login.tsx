import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { toast } from "sonner";
import { ArrowLeft, Lock, ShieldCheck } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Glass, Kicker } from "../../components/shared/glass";
import { FeatureLabel } from "../../components/shared/status";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Signed in. Opening your client platform…");
    navigate("/platform");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-ice via-cream to-blush px-5 py-10 sm:px-8">
      <div className="mx-auto flex min-h-[calc(100vh-5rem)] max-w-5xl items-center">
        <div className="grid w-full gap-8 lg:grid-cols-[0.9fr_1fr] lg:gap-12">
          {/* Brand panel */}
          <div className="hidden flex-col justify-center lg:flex">
            <Kicker>Client platform</Kicker>
            <h1 className="mt-5 text-[2.6rem] leading-[1.05] text-charcoal">
              Welcome back to your <span className="text-aqua">workspace.</span>
            </h1>
            <p className="mt-5 max-w-md text-[1.02rem] leading-relaxed text-muted-foreground">
              View your website status, request updates, track invoices, and stay
              organized — all in one calm, private place.
            </p>
            <div className="mt-8 flex flex-col gap-3">
              {[
                { i: ShieldCheck, t: "Your data stays isolated from other clients" },
                { i: Lock, t: "No code access — your site stays protected" },
              ].map((b) => (
                <div key={b.t} className="flex items-center gap-3 rounded-xl border border-white/60 bg-white/50 p-3.5 backdrop-blur-md">
                  <b.i className="h-4 w-4 shrink-0 text-aqua" />
                  <span className="text-[0.85rem] text-charcoal">{b.t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Login card */}
          <div className="flex flex-col justify-center">
            <Glass className="p-7 sm:p-9">
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-aqua text-cream">
                  <ShieldCheck className="h-4 w-4" />
                </span>
                <div className="leading-tight">
                  <div className="text-[1rem] text-charcoal">Client sign in</div>
                  <div className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-muted-foreground">Aalia Systems</div>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="mt-7 flex flex-col gap-5">
                <div className="flex flex-col gap-2">
                  <Label className="text-[0.85rem] text-charcoal">Email</Label>
                  <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@business.com" />
                </div>
                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-[0.85rem] text-charcoal">Password</Label>
                    <Link to="/contact" className="text-[0.78rem] text-aqua underline-offset-2 hover:underline">Forgot password?</Link>
                  </div>
                  <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" />
                </div>
                <Button type="submit" className="h-11 bg-aqua text-cream hover:bg-aqua-bright">Sign in</Button>
              </form>

              <div className="my-5 flex items-center gap-3">
                <span className="h-px flex-1 bg-border" />
                <span className="font-mono text-[0.65rem] uppercase tracking-wide text-muted-foreground">or</span>
                <span className="h-px flex-1 bg-border" />
              </div>

              <Button variant="outline" className="w-full justify-center gap-2 border-aqua/30 text-aqua hover:bg-white" disabled>
                Continue with Google
                <FeatureLabel state="Planned" />
              </Button>

              <div className="mt-6 flex items-start gap-2.5 rounded-xl border border-white/60 bg-white/50 p-3.5">
                <Lock className="mt-0.5 h-3.5 w-3.5 shrink-0 text-aqua" />
                <p className="text-[0.78rem] leading-relaxed text-muted-foreground">
                  This is a prototype login. Data is isolated per client and no code
                  access is provided. No real authentication is performed.
                </p>
              </div>
            </Glass>

            <Link to="/" className="mt-6 inline-flex items-center gap-1.5 text-[0.85rem] text-aqua underline-offset-2 hover:underline">
              <ArrowLeft className="h-3.5 w-3.5" /> Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
