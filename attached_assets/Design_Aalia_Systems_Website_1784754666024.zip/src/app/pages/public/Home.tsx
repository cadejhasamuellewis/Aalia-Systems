import { Link } from "react-router";
import { ArrowRight, Check, Lock, Globe, ShieldCheck, LayoutDashboard, ChevronDown } from "lucide-react";
import { useState } from "react";
import { Button } from "../../components/ui/button";
import { Glass, Chip, Kicker } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { StatusPill } from "../../components/shared/status";

// ─── Mini dashboard preview ───────────────────────────────────────────────────
function DashPreview() {
  const rows = [
    { label: "Website", value: "Online", tone: "ok" as const },
    { label: "Domain", value: "Connected", tone: "ok" as const },
    { label: "SSL", value: "Active", tone: "ok" as const },
    { label: "Monthly support", value: "Active", tone: "aqua" as const },
    { label: "Update request", value: "Pending", tone: "warn" as const },
    { label: "Invoice", value: "Paid · Square", tone: "ok" as const },
    { label: "Approved edits", value: "Available", tone: "info" as const },
  ];
  return (
    <div className="w-full max-w-sm rounded-2xl border border-white/60 bg-white/65 p-5 shadow-[0_20px_60px_-20px_rgba(22,86,92,0.25)] backdrop-blur-xl">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <div className="font-display text-[0.95rem] text-charcoal">Marigold &amp; Co. Studio</div>
          <div className="font-mono text-[0.62rem] uppercase tracking-widest text-copper">Managed Website + Platform</div>
        </div>
        <StatusPill tone="aqua" dot>Active</StatusPill>
      </div>
      <div className="space-y-2">
        {rows.map((r) => (
          <div key={r.label} className="flex items-center justify-between rounded-lg bg-ice/40 px-3.5 py-2.5">
            <span className="text-[0.83rem] text-slate">{r.label}</span>
            <StatusPill tone={r.tone} dot={false}>{r.value}</StatusPill>
          </div>
        ))}
      </div>
      <div className="mt-3 text-center font-mono text-[0.58rem] uppercase tracking-wide text-muted-foreground">
        Sample client dashboard preview
      </div>
    </div>
  );
}

// ─── Add-on accordion ─────────────────────────────────────────────────────────
const addOns = [
  { label: "Business documents", detail: "Branded templates, agreements, policy documents, and client-facing PDFs." },
  { label: "Fillable forms", detail: "Intake forms, approval forms, and fillable PDFs for your business workflow." },
  { label: "Email templates", detail: "Branded HTML email templates for announcements, confirmations, and follow-ups." },
  { label: "Domain + hosting coordination", detail: "Help organizing your domain, DNS records, SSL, and hosting provider — included in monthly support." },
  { label: "Basic SEO setup", detail: "Page titles, meta descriptions, image alt text, and basic on-page setup. Educational resources provided." },
  { label: "Website files", detail: "Organized file delivery — source files, brand assets, copy documents, and export packages." },
];

function AddOnItem({ label, detail }: { label: string; detail: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-border last:border-0">
      <button
        type="button"
        className="flex w-full items-center justify-between py-4 text-left"
        onClick={() => setOpen((v) => !v)}
      >
        <span className="text-[0.95rem] text-charcoal">{label}</span>
        <ChevronDown className={`h-4 w-4 shrink-0 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <p className="pb-4 text-[0.88rem] leading-relaxed text-muted-foreground">{detail}</p>
      )}
    </div>
  );
}

// ─── Pricing cards ────────────────────────────────────────────────────────────
const plans = [
  {
    name: "Website Project",
    price: "Starting at $—",
    desc: "A new website or redesign built around your business.",
    features: ["Custom design", "Mobile-first layout", "Contact/inquiry flow", "Launch coordination"],
    featured: false,
  },
  {
    name: "Monthly Support",
    price: "Monthly from $—",
    desc: "Updates, checks, domain/SSL notes, and support after launch.",
    features: ["Monthly website checks", "Update requests", "Domain + SSL tracking", "Care report", "Client platform access"],
    featured: true,
  },
  {
    name: "Managed Website + Platform",
    price: "Monthly from $—",
    desc: "Care plus full dashboard access, approved edits, invoices, and files.",
    features: ["Everything in care", "Approved content editing", "File uploads + approvals", "Invoices + subscriptions", "Priority support"],
    featured: false,
  },
];

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <>
      {/* ── Hero ── */}
      <section className="px-5 pb-10 pt-14 sm:px-8 sm:pt-20">
        <div className="mx-auto grid max-w-7xl items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="flex flex-col gap-7">
            <Kicker>Woman-owned website management studio</Kicker>
            <h1 className="text-[2.8rem] leading-[1.04] text-charcoal sm:text-[3.6rem]">
              Your website,<br />
              <span className="text-aqua">managed after launch.</span>
            </h1>
            <p className="max-w-md text-[1.05rem] leading-relaxed text-muted-foreground">
              Aalia builds professional websites and manages updates, domain details, files, invoices, and support through one private client platform.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild className="h-12 bg-aqua px-6 text-cream hover:bg-aqua-bright">
                <Link to="/start">Start a project <ArrowRight className="ml-1.5 h-4 w-4" /></Link>
              </Button>
              <Button asChild variant="outline" className="h-12 border-aqua/30 bg-white/50 px-6 text-aqua hover:bg-white">
                <Link to="/care">Monthly support plans</Link>
              </Button>
            </div>
          </div>
          <div className="flex justify-center lg:justify-end">
            <DashPreview />
          </div>
        </div>
      </section>

      {/* ── Three Core Cards ── */}
      <Section>
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              icon: Globe,
              label: "Build",
              title: "Professional websites and redesigns.",
              desc: "Custom websites built around your business, brand, and client experience.",
              to: "/services",
            },
            {
              icon: ShieldCheck,
              label: "Manage",
              title: "Monthly support after launch.",
              desc: "Updates, website checks, domain and SSL tracking, and human support.",
              to: "/care",
            },
            {
              icon: LayoutDashboard,
              label: "Platform",
              title: "A private client dashboard.",
              desc: "Requests, files, invoices, subscriptions, and approved content edits in one place.",
              to: "/platform-overview",
            },
          ].map((c) => (
            <Link key={c.label} to={c.to} className="group block">
              <Glass className="flex h-full flex-col gap-5 p-7 transition-transform hover:-translate-y-0.5">
                <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-aqua/10 text-aqua">
                  <c.icon className="h-5 w-5" />
                </span>
                <div>
                  <div className="font-mono text-[0.65rem] uppercase tracking-[0.18em] text-copper mb-1">{c.label}</div>
                  <h3 className="text-[1.05rem] leading-snug text-charcoal">{c.title}</h3>
                  <p className="mt-2 text-[0.88rem] leading-relaxed text-muted-foreground">{c.desc}</p>
                </div>
                <div className="mt-auto flex items-center gap-1.5 text-[0.85rem] text-aqua opacity-0 transition-opacity group-hover:opacity-100">
                  Learn more <ArrowRight className="h-3.5 w-3.5" />
                </div>
              </Glass>
            </Link>
          ))}
        </div>
      </Section>

      {/* ── Client Platform Preview ── */}
      <Section>
        <Glass tint="ice" className="overflow-hidden p-0">
          <div className="grid gap-0 lg:grid-cols-2">
            <div className="flex flex-col justify-center gap-5 p-10 lg:p-14">
              <Kicker>Client platform</Kicker>
              <h2 className="text-[2rem] leading-tight text-charcoal">
                A private workspace for your website.
              </h2>
              <p className="text-[0.95rem] leading-relaxed text-muted-foreground">
                Monthly clients get access to a private dashboard where they can submit update requests, upload files, view invoices and subscriptions, and edit approved content — without touching code.
              </p>
              <div className="flex flex-wrap gap-2 mt-1">
                {["Website status", "Update requests", "Files", "Invoices", "Subscriptions", "Approved edits"].map((f) => (
                  <Chip key={f}>{f}</Chip>
                ))}
              </div>
              <Button asChild className="mt-2 w-fit bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/platform-overview">Explore the platform</Link>
              </Button>
            </div>
            <div className="flex items-center justify-center border-t border-white/40 p-8 lg:border-l lg:border-t-0">
              <div className="w-full max-w-xs rounded-xl border border-white/70 bg-white/70 shadow-sm overflow-hidden">
                {/* Sidebar mini nav */}
                <div className="flex h-full">
                  <div className="flex flex-col gap-0.5 border-r border-white/50 bg-white/40 p-2.5 w-32 shrink-0">
                    {["Overview", "Website", "Edit Content", "Requests", "Files", "Invoices", "Support"].map((n, i) => (
                      <div key={n} className={`rounded-lg px-2.5 py-2 font-mono text-[0.6rem] ${i === 0 ? "bg-aqua text-cream" : "text-slate"}`}>{n}</div>
                    ))}
                  </div>
                  <div className="flex flex-col gap-2 p-3 flex-1">
                    {[
                      { l: "Website", v: "Online", ok: true },
                      { l: "SSL", v: "Active", ok: true },
                      { l: "Request", v: "In review", ok: false },
                      { l: "Invoice", v: "Paid", ok: true },
                    ].map((r) => (
                      <div key={r.l} className="rounded-md bg-ice/50 px-2.5 py-2">
                        <div className="font-mono text-[0.55rem] text-muted-foreground">{r.l}</div>
                        <div className={`font-mono text-[0.68rem] ${r.ok ? "text-aqua" : "text-copper"}`}>{r.v}</div>
                      </div>
                    ))}
                    <div className="mt-1 rounded-md border border-dashed border-aqua/30 px-2.5 py-2 text-[0.6rem] text-aqua text-center">Approved edits available</div>
                    <div className="text-center font-mono text-[0.52rem] text-muted-foreground mt-1">Sample dashboard preview</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Glass>
      </Section>

      {/* ── Brand-Safe Editing ── */}
      <Section>
        <Glass tint="cream" className="p-10 lg:p-14">
          <div className="grid gap-12 lg:grid-cols-2">
            <div className="flex flex-col gap-5">
              <Kicker>Brand-safe content editing</Kicker>
              <h2 className="text-[2rem] leading-tight text-charcoal">
                Edit approved content without breaking your website.
              </h2>
              <p className="text-[0.95rem] leading-relaxed text-muted-foreground">
                Monthly clients can update approved text, images, hours, announcements, and service details — while the layout, code, spacing, colors, and brand system stay protected.
              </p>
              <Button asChild className="mt-2 w-fit bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/platform-overview">How it works</Link>
              </Button>
            </div>
            <div className="flex flex-col gap-5">
              {/* 3-step visual */}
              {[
                { n: "01", title: "Choose an approved section", body: "Select from your approved content areas — text fields, image slots, or announcement blocks." },
                { n: "02", title: "Edit and preview", body: "Make your changes in a simple editor and preview how they appear on your website." },
                { n: "03", title: "Publish or submit for review", body: "Publish directly if your plan allows it, or submit for Aalia's review before it goes live." },
              ].map((s) => (
                <div key={s.n} className="flex gap-4">
                  <span className="font-mono text-[1.1rem] text-copper shrink-0 w-8">{s.n}</span>
                  <div>
                    <div className="text-[0.95rem] text-charcoal">{s.title}</div>
                    <p className="mt-1 text-[0.85rem] leading-relaxed text-muted-foreground">{s.body}</p>
                  </div>
                </div>
              ))}
              <div className="mt-2 flex flex-wrap gap-2">
                {[
                  { i: Lock, t: "Code stays locked" },
                  { i: Lock, t: "Layout protected" },
                  { i: Check, t: "Brand rules intact" },
                ].map((b) => (
                  <div key={b.t} className="flex items-center gap-1.5 rounded-full border border-white/60 bg-white/60 px-3 py-1.5 text-[0.82rem] text-slate">
                    <b.i className="h-3 w-3 text-aqua" />{b.t}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Glass>
      </Section>

      {/* ── Add-On Support ── */}
      <Section>
        <div className="mx-auto max-w-2xl">
          <SectionHeading
            kicker="Add-on support"
            title="Add support when you need it."
            support="Additional services available alongside any project or monthly plan."
          />
          <Glass className="mt-8 px-7 py-2">
            {addOns.map((a) => <AddOnItem key={a.label} label={a.label} detail={a.detail} />)}
          </Glass>
        </div>
      </Section>

      {/* ── Pricing Preview ── */}
      <Section>
        <SectionHeading
          kicker="Plans"
          title="Simple pricing."
          support="Placeholder rates — contact for a custom quote."
          align="center"
          className="mx-auto items-center"
        />
        <div className="mt-9 grid gap-4 lg:grid-cols-3">
          {plans.map((p) => (
            <Glass key={p.name} className={`flex flex-col gap-5 p-7 ${p.featured ? "ring-2 ring-aqua/40" : ""}`}>
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-[1.05rem] leading-snug text-charcoal">{p.name}</h3>
                {p.featured && <StatusPill tone="aqua" dot={false}>Popular</StatusPill>}
              </div>
              <div className="font-mono text-[1.05rem] text-aqua">{p.price}</div>
              <p className="text-[0.88rem] text-muted-foreground">{p.desc}</p>
              <ul className="space-y-2">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-[0.85rem] text-slate">
                    <Check className="h-3.5 w-3.5 shrink-0 text-aqua" />{f}
                  </li>
                ))}
              </ul>
              <Button asChild variant="outline" className="mt-auto border-aqua/30 text-aqua hover:bg-white">
                <Link to="/pricing">See details</Link>
              </Button>
            </Glass>
          ))}
        </div>
      </Section>

      {/* ── Final CTA ── */}
      <Section>
        <Glass tint="aqua" className="flex flex-col items-center gap-7 p-12 text-center sm:p-20">
          <h2 className="max-w-lg text-[2.1rem] leading-tight text-charcoal">
            Ready for a website that does not get left alone after launch?
          </h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-12 bg-aqua px-7 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a project</Link>
            </Button>
            <Button asChild variant="outline" className="h-12 border-aqua/30 bg-white/60 px-7 text-aqua hover:bg-white">
              <Link to="/care">Monthly support plans</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
