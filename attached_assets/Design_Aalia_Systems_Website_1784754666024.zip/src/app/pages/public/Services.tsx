import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { Icon } from "../../components/shared/icon";
import { services } from "../../data/mock";

const serviceLinks: Record<string, string> = {
  care: "/care",
  platform: "/platform-overview",
  brand: "/branding",
  docs: "/branding",
  pos: "/pos",
};

export default function Services() {
  return (
    <>
      <PageHero
        kicker="Services"
        title="Digital systems that make your business easier to run."
        support="From first build to ongoing care — websites, brand, documents, and the platform that keeps it all organized."
      />

      <Section>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((s) => {
            const to = serviceLinks[s.id] ?? "/start";
            return (
              <Glass key={s.id} className="group flex flex-col gap-4 p-6 transition-transform hover:-translate-y-0.5">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-ice/70 text-aqua">
                  <Icon name={s.icon} className="h-5 w-5" />
                </span>
                <h3 className="text-[1.1rem] text-charcoal">{s.title}</h3>
                <p className="text-[0.9rem] leading-relaxed text-muted-foreground">{s.blurb}</p>
                <Link
                  to={to}
                  className="mt-auto inline-flex items-center gap-1.5 text-[0.85rem] text-aqua transition-colors group-hover:text-aqua-bright"
                >
                  Learn more <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </Glass>
            );
          })}
        </div>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <SectionHeading
            align="center"
            title="Not sure which service fits?"
            support="Tell us about your business and we'll map the right combination of build and care."
            className="mx-auto items-center"
          />
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a project</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/pricing">See pricing</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
