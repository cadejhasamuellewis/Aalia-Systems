import { Link } from "react-router";
import { Heart, Compass, ShieldCheck, Sparkles, Users, Building2, Stethoscope, ShoppingBag } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";

const values = [
  { i: Heart, t: "Warm + human", d: "Real people, real support — never a ticket lost in a void." },
  { i: Compass, t: "Calm + organized", d: "Clear systems so nothing important slips through the cracks." },
  { i: ShieldCheck, t: "Honest boundaries", d: "We're careful about what we promise and clear about what we don't do." },
  { i: Sparkles, t: "Considered craft", d: "Premium, technical work that still feels approachable." },
];

const serve = [
  { i: Building2, t: "Small businesses" },
  { i: Users, t: "Service providers" },
  { i: Building2, t: "Professional offices" },
  { i: ShoppingBag, t: "E-commerce" },
  { i: Stethoscope, t: "Healthcare-adjacent practices" },
];

export default function About() {
  return (
    <>
      <PageHero
        kicker="About Aalia Systems"
        title="A woman-owned digital studio that treats your website like a system, not a one-off."
        support="Premium and technical, calm and warm — built to make running your digital business genuinely easier."
      />

      <Section>
        <Glass className="grid gap-8 p-8 lg:grid-cols-2 lg:p-12" tint="ice">
          <div>
            <SectionHeading kicker="Our story" title="Built for business owners who wear too many hats." />
          </div>
          <div className="space-y-4 text-[0.95rem] leading-relaxed text-slate">
            <p>
              Aalia Systems began with a simple observation: most small businesses
              get a website, then get left alone with it. Updates pile up, renewals
              lapse, and the site slowly drifts out of date.
            </p>
            <p>
              We do it differently. We design and build with care, then keep your
              website and digital systems organized through one clear workflow — so
              you always know what's happening and what's next.
            </p>
            <p>
              As a woman-owned, Black-owned creative studio, we bring a point of view
              that's both technical and human: sharp systems, warm support.
            </p>
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="What we value" title="How we work." />
        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {values.map((v) => (
            <Glass key={v.t} className="flex flex-col gap-4 p-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ice/70 text-aqua"><v.i className="h-5 w-5" /></span>
              <h3 className="text-[1.05rem] text-charcoal">{v.t}</h3>
              <p className="text-[0.88rem] leading-relaxed text-muted-foreground">{v.d}</p>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <Glass className="p-8 lg:p-12" tint="cream">
          <SectionHeading kicker="Our approach" title="Design, build, and ongoing care — in one place." support="We don't hand you a website and disappear. We stay organized alongside you." />
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {[
              { n: "01", t: "Understand", b: "We learn your business, brand, and where you feel stuck." },
              { n: "02", t: "Build", b: "We design or restructure your site around your clients." },
              { n: "03", t: "Care", b: "We keep it current with organized, ongoing support." },
            ].map((s) => (
              <div key={s.n} className="rounded-xl border border-white/60 bg-white/60 p-6">
                <span className="font-mono text-[1.4rem] text-copper">{s.n}</span>
                <h3 className="mt-2 text-[1.05rem] text-charcoal">{s.t}</h3>
                <p className="mt-1.5 text-[0.88rem] leading-relaxed text-muted-foreground">{s.b}</p>
              </div>
            ))}
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Who we serve" title="Businesses that want to look and run their best." />
        <div className="mt-9 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {serve.map((s) => (
            <Glass key={s.t} className="flex flex-col items-center gap-3 p-6 text-center">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ice/70 text-aqua"><s.i className="h-5 w-5" /></span>
              <span className="text-[0.88rem] leading-tight text-charcoal">{s.t}</span>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">Let's build something that lasts.</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a project</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/contact">Get in touch</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
