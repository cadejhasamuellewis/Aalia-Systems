import { useState } from "react";
import { Link } from "react-router";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, Check, CheckCircle2, UploadCloud } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Textarea } from "../../components/ui/textarea";
import { Label } from "../../components/ui/label";
import { Checkbox } from "../../components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "../../components/ui/radio-group";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "../../components/ui/select";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { StatusPill } from "../../components/shared/status";

const serviceOptions = [
  "New website", "Website redesign", "Monthly support plan", "Branding",
  "Business documents / forms", "E-commerce", "POS setup support",
  "Client dashboard", "Domain / hosting help", "SEO setup", "Long-term support",
];

const budgets = ["Under $1,000", "$1,000 – $3,000", "$3,000 – $6,000", "$6,000+", "Not sure yet"];
const timelines = ["As soon as possible", "1–3 months", "3–6 months", "Just exploring"];
const domainStatuses = ["I already have a domain + hosting", "I have a domain only", "I need help getting both", "Not sure"];

const steps = ["Your business", "What you need", "Details", "Files + consent"];

export default function Start() {
  const [step, setStep] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, boolean>>({});

  const [business, setBusiness] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [website, setWebsite] = useState("");
  const [needs, setNeeds] = useState("");
  const [services, setServices] = useState<string[]>([]);
  const [budget, setBudget] = useState("");
  const [timeline, setTimeline] = useState("");
  const [brandAssets, setBrandAssets] = useState("");
  const [domainStatus, setDomainStatus] = useState("");
  const [contactPref, setContactPref] = useState("Email");
  const [consent, setConsent] = useState(false);

  const toggleService = (s: string) =>
    setServices((prev) => (prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]));

  const validateStep = (i: number) => {
    const e: Record<string, boolean> = {};
    if (i === 0) {
      if (!business.trim()) e.business = true;
      if (!name.trim()) e.name = true;
      if (!email.trim()) e.email = true;
    }
    if (i === 1 && services.length === 0) e.services = true;
    if (i === 3 && !consent) e.consent = true;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const next = () => {
    if (validateStep(step)) setStep((s) => Math.min(s + 1, steps.length - 1));
    else toast.error("Please complete the required fields.");
  };
  const back = () => setStep((s) => Math.max(s - 1, 0));

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validateStep(3)) {
      toast.error("Please agree to the terms to continue.");
      return;
    }
    setSubmitted(true);
    toast.success("Your project request was sent. We'll be in touch soon.");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  if (submitted) {
    return (
      <Section>
        <Glass className="mx-auto flex max-w-xl flex-col items-center gap-5 p-10 text-center sm:p-14" tint="aqua">
          <span className="flex h-14 w-14 items-center justify-center rounded-full bg-aqua text-cream">
            <CheckCircle2 className="h-7 w-7" />
          </span>
          <h1 className="text-[2rem] leading-tight text-charcoal">Thank you, {name || "there"}.</h1>
          <p className="max-w-md text-[0.95rem] leading-relaxed text-muted-foreground">
            Your project request for <span className="text-charcoal">{business || "your business"}</span> has
            been received. We'll review your details and reach out within a couple of business days.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/">Back to home</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/platform-overview">Explore the platform</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    );
  }

  const progress = ((step + 1) / steps.length) * 100;

  return (
    <>
      <PageHero
        kicker="Start a project"
        title="Tell us what your business needs."
        support="A few guided questions so we can prepare the right plan and quote. It takes about three minutes."
      />

      <Section>
        {/* Step indicator */}
        <div className="mb-8">
          <div className="flex flex-wrap items-center gap-2">
            {steps.map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <span
                  className={`flex h-7 w-7 items-center justify-center rounded-full font-mono text-[0.72rem] ${
                    i < step ? "bg-aqua text-cream" : i === step ? "bg-aqua/15 text-aqua ring-2 ring-aqua/40" : "bg-muted text-muted-foreground"
                  }`}
                >
                  {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
                </span>
                <span className={`text-[0.82rem] ${i === step ? "text-charcoal" : "text-muted-foreground"}`}>{s}</span>
                {i < steps.length - 1 && <span className="mx-1 hidden h-px w-6 bg-border sm:block" />}
              </div>
            ))}
          </div>
          <div className="mt-4 h-1.5 w-full overflow-hidden rounded-full bg-muted">
            <div className="h-full rounded-full bg-aqua transition-all" style={{ width: `${progress}%` }} />
          </div>
        </div>

        <Glass className="p-6 sm:p-9">
          <form onSubmit={handleSubmit} className="flex flex-col gap-7">
            {step === 0 && (
              <div className="flex flex-col gap-6">
                <SectionHeading kicker="Step 1" title="Your business" />
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Business name" required error={errors.business}>
                    <Input value={business} onChange={(e) => setBusiness(e.target.value)} placeholder="Marigold & Co." />
                  </Field>
                  <Field label="Your name" required error={errors.name}>
                    <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name" />
                  </Field>
                  <Field label="Email" required error={errors.email}>
                    <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@business.com" />
                  </Field>
                  <Field label="Current website (if any)">
                    <Input value={website} onChange={(e) => setWebsite(e.target.value)} placeholder="yoursite.com" />
                  </Field>
                </div>
              </div>
            )}

            {step === 1 && (
              <div className="flex flex-col gap-6">
                <SectionHeading kicker="Step 2" title="What do you need?" />
                <Field label="Tell us what you're looking for">
                  <Textarea value={needs} onChange={(e) => setNeeds(e.target.value)} rows={4} placeholder="A short description of your goals and where you feel stuck." />
                </Field>
                <div>
                  <Label className="text-[0.85rem] text-charcoal">
                    Services interested in <span className="text-copper">*</span>
                  </Label>
                  <div className="mt-3 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
                    {serviceOptions.map((s) => (
                      <label
                        key={s}
                        className={`flex cursor-pointer items-center gap-3 rounded-xl border p-3.5 transition-colors ${
                          services.includes(s) ? "border-aqua/40 bg-aqua/10" : "border-white/60 bg-white/60 hover:bg-white"
                        }`}
                      >
                        <Checkbox checked={services.includes(s)} onCheckedChange={() => toggleService(s)} />
                        <span className="text-[0.86rem] text-charcoal">{s}</span>
                      </label>
                    ))}
                  </div>
                  {errors.services && <p className="mt-2 text-[0.78rem] text-destructive">Please select at least one service.</p>}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="flex flex-col gap-6">
                <SectionHeading kicker="Step 3" title="A few more details" />
                <div className="grid gap-5 sm:grid-cols-2">
                  <Field label="Budget range">
                    <Select value={budget} onValueChange={setBudget}>
                      <SelectTrigger><SelectValue placeholder="Select a range" /></SelectTrigger>
                      <SelectContent>
                        {budgets.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                  <Field label="Timeline">
                    <Select value={timeline} onValueChange={setTimeline}>
                      <SelectTrigger><SelectValue placeholder="Select a timeline" /></SelectTrigger>
                      <SelectContent>
                        {timelines.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </Field>
                </div>
                <Field label="Brand assets">
                  <Textarea value={brandAssets} onChange={(e) => setBrandAssets(e.target.value)} rows={3} placeholder="Do you have a logo, colors, or brand guide already? Tell us what exists." />
                </Field>
                <div>
                  <Label className="text-[0.85rem] text-charcoal">Domain / hosting status</Label>
                  <RadioGroup value={domainStatus} onValueChange={setDomainStatus} className="mt-3 grid gap-2.5">
                    {domainStatuses.map((d) => (
                      <label key={d} className="flex cursor-pointer items-center gap-3 rounded-xl border border-white/60 bg-white/60 p-3.5 hover:bg-white">
                        <RadioGroupItem value={d} /> <span className="text-[0.86rem] text-charcoal">{d}</span>
                      </label>
                    ))}
                  </RadioGroup>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="flex flex-col gap-6">
                <SectionHeading kicker="Step 4" title="Files, contact + consent" />
                <div>
                  <Label className="text-[0.85rem] text-charcoal">Upload files</Label>
                  <div className="mt-3 flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-aqua/30 bg-ice/30 p-8 text-center">
                    <UploadCloud className="h-8 w-8 text-aqua" />
                    <p className="text-[0.9rem] text-charcoal">Drag files here or click to browse</p>
                    <p className="text-[0.75rem] text-muted-foreground">Logos, brand guides, references (UI only in this prototype)</p>
                  </div>
                </div>
                <div>
                  <Label className="text-[0.85rem] text-charcoal">Preferred contact method</Label>
                  <RadioGroup value={contactPref} onValueChange={setContactPref} className="mt-3 flex flex-wrap gap-2.5">
                    {["Email", "Phone", "Either"].map((c) => (
                      <label key={c} className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-white/60 bg-white/60 px-4 py-3 hover:bg-white">
                        <RadioGroupItem value={c} /> <span className="text-[0.86rem] text-charcoal">{c}</span>
                      </label>
                    ))}
                  </RadioGroup>
                </div>
                <label className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 ${errors.consent ? "border-destructive/50 bg-destructive/5" : "border-white/60 bg-white/60"}`}>
                  <Checkbox checked={consent} onCheckedChange={(v) => setConsent(v === true)} className="mt-0.5" />
                  <span className="text-[0.86rem] leading-relaxed text-slate">
                    I agree to be contacted about my request and accept the{" "}
                    <Link to="/terms" className="text-aqua underline-offset-2 hover:underline">terms</Link> and{" "}
                    <Link to="/privacy" className="text-aqua underline-offset-2 hover:underline">privacy policy</Link>.{" "}
                    <span className="text-copper">*</span>
                  </span>
                </label>
                {errors.consent && <p className="-mt-4 text-[0.78rem] text-destructive">You must agree to continue.</p>}
              </div>
            )}

            {/* Nav */}
            <div className="flex items-center justify-between gap-3 border-t border-border/60 pt-6">
              <Button type="button" variant="outline" onClick={back} disabled={step === 0} className="border-aqua/30 text-aqua hover:bg-white disabled:opacity-40">
                <ArrowLeft className="mr-1.5 h-4 w-4" /> Back
              </Button>
              <StatusPill tone="aqua" dot={false}>Step {step + 1} of {steps.length}</StatusPill>
              {step < steps.length - 1 ? (
                <Button type="button" onClick={next} className="bg-aqua text-cream hover:bg-aqua-bright">
                  Continue <ArrowRight className="ml-1.5 h-4 w-4" />
                </Button>
              ) : (
                <Button type="submit" className="bg-aqua text-cream hover:bg-aqua-bright">
                  Submit request <Check className="ml-1.5 h-4 w-4" />
                </Button>
              )}
            </div>
          </form>
        </Glass>
      </Section>
    </>
  );
}

function Field({
  label, required, error, children,
}: {
  label: string; required?: boolean; error?: boolean; children: React.ReactNode;
}) {
  return (
    <div className="flex flex-col gap-2">
      <Label className="text-[0.85rem] text-charcoal">
        {label} {required && <span className="text-copper">*</span>}
      </Label>
      {children}
      {error && <span className="text-[0.78rem] text-destructive">This field is required.</span>}
    </div>
  );
}
