import { Glass } from "../../components/shared/glass";
import { Section } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { FeatureLabel } from "../../components/shared/status";

const sections = [
  {
    h: "Information we collect",
    p: "We collect information you provide directly — such as your name, business name, email, project details, and any files you share — along with basic technical information (like device and usage data) when you visit our website.",
  },
  {
    h: "How we use your information",
    p: "We use your information to respond to inquiries, prepare quotes, deliver our services, manage your client platform, send invoices and updates, and improve how we work. We do not sell your personal information.",
  },
  {
    h: "Third-party services",
    p: "We rely on trusted third parties to operate — for example, payment processing (such as Square), website hosting, and domain providers. These services process data under their own terms and privacy policies. We share only what's needed to provide our services.",
  },
  {
    h: "Client data isolation",
    p: "Each client's workspace and files are kept logically separated within the client platform. Clients do not have access to code, and we limit access to client data to what is necessary to deliver support.",
  },
  {
    h: "Protected health information (PHI)",
    p: "Aalia Systems is not an EHR and does not store or process protected health information. For healthcare-adjacent clients, PHI remains within your own approved EHR system. We are not HIPAA compliant unless formally verified in writing for a specific engagement.",
  },
  {
    h: "Cookies",
    p: "Our website may use basic cookies and similar technologies to keep the site functioning and to understand general usage. You can control cookies through your browser settings.",
  },
  {
    h: "Contact",
    p: "For any questions about this policy or your data, contact us at hello@aaliasystems.com.",
  },
];

export default function Privacy() {
  return (
    <>
      <PageHero kicker="Legal" title="Privacy Policy" support="How we handle the information you share with us." />
      <Section>
        <Glass className="mx-auto max-w-3xl p-8 sm:p-12">
          <div className="mb-6 flex flex-wrap items-center gap-3">
            <FeatureLabel state="Requires legal review" />
            <span className="font-mono text-[0.7rem] uppercase tracking-[0.14em] text-muted-foreground">Last updated: July 2026</span>
          </div>
          <p className="text-[0.92rem] leading-relaxed text-muted-foreground">
            This policy describes how Aalia Systems collects, uses, and protects
            information. It is a working draft and should be reviewed by legal counsel
            before publication.
          </p>
          <div className="mt-8 space-y-8">
            {sections.map((s) => (
              <div key={s.h}>
                <h2 className="text-[1.2rem] text-charcoal">{s.h}</h2>
                <p className="mt-2 text-[0.92rem] leading-relaxed text-slate">{s.p}</p>
              </div>
            ))}
          </div>
        </Glass>
      </Section>
    </>
  );
}
