import { Link } from "react-router";
import { Palette, Type, BookOpen, Share2, CreditCard, FileText, FileCheck, ClipboardList, FileSignature, Files } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";

const swatches = [
  { name: "Aqua", cls: "bg-aqua", hex: "Primary" },
  { name: "Aqua Bright", cls: "bg-aqua-bright", hex: "Accent" },
  { name: "Copper", cls: "bg-copper", hex: "Detail" },
  { name: "Ice", cls: "bg-ice", hex: "Surface" },
  { name: "Cream", cls: "bg-cream", hex: "Base" },
  { name: "Blush", cls: "bg-blush", hex: "Soft" },
  { name: "Pearl", cls: "bg-pearl", hex: "Neutral" },
  { name: "Charcoal", cls: "bg-charcoal", hex: "Text" },
];

const cards = [
  { i: BookOpen, t: "Logo direction", d: "Concepts, lockups, and usage guidance for a consistent mark." },
  { i: Share2, t: "Social templates", d: "On-brand post and story layouts your team can reuse." },
  { i: CreditCard, t: "Business cards", d: "Print-ready card designs matched to your identity." },
  { i: FileText, t: "Flyers", d: "Promotional and event flyers in your brand style." },
  { i: FileCheck, t: "Fillable forms", d: "Interactive PDFs clients can complete and return." },
  { i: ClipboardList, t: "Intake forms", d: "Structured intake documents for smooth onboarding." },
  { i: FileSignature, t: "PDF templates", d: "Reusable branded templates for recurring documents." },
  { i: Files, t: "Client documents", d: "Agreements, welcome packets, and handoff materials." },
];

export default function Branding() {
  return (
    <>
      <PageHero
        kicker="Branding + documents"
        title="A consistent brand, from screen to paper."
        support="Visual identity, templates, and business documents that make everything you send feel considered and cohesive."
      />

      <Section>
        <div className="grid gap-4 lg:grid-cols-2">
          <Glass className="flex flex-col gap-5 p-8">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ice/70 text-aqua">
              <Palette className="h-5 w-5" />
            </span>
            <SectionHeading kicker="Color palette" title="A palette that holds together." />
            <div className="grid grid-cols-4 gap-3">
              {swatches.map((s) => (
                <div key={s.name} className="flex flex-col gap-2">
                  <div className={`h-16 w-full rounded-xl border border-white/60 ${s.cls}`} />
                  <div>
                    <div className="text-[0.78rem] text-charcoal">{s.name}</div>
                    <div className="font-mono text-[0.6rem] uppercase tracking-wide text-muted-foreground">{s.hex}</div>
                  </div>
                </div>
              ))}
            </div>
          </Glass>

          <Glass className="flex flex-col gap-5 p-8">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ice/70 text-aqua">
              <Type className="h-5 w-5" />
            </span>
            <SectionHeading kicker="Typography" title="Type that carries the tone." />
            <div className="space-y-5">
              <div className="rounded-xl border border-white/60 bg-white/60 p-5">
                <div className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-muted-foreground">Headings · Fraunces</div>
                <h3 className="mt-2 text-[1.8rem] leading-tight text-charcoal">Warm, editorial, and calm.</h3>
              </div>
              <div className="rounded-xl border border-white/60 bg-white/60 p-5">
                <div className="font-mono text-[0.6rem] uppercase tracking-[0.14em] text-muted-foreground">Body · Figtree</div>
                <p className="mt-2 text-[0.95rem] leading-relaxed text-slate">
                  Clean, readable body text for everything from web pages to printed
                  documents — approachable without feeling casual.
                </p>
              </div>
            </div>
          </Glass>
        </div>
      </Section>

      <Section>
        <SectionHeading kicker="Brand guide" title="Everything documented in one place." support="A living reference so your brand stays consistent no matter who's applying it." />
        <div className="mt-9 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {cards.map((c) => (
            <Glass key={c.t} className="flex flex-col gap-4 p-6 transition-transform hover:-translate-y-0.5">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-ice/70 text-aqua">
                <c.i className="h-5 w-5" />
              </span>
              <h3 className="text-[1rem] text-charcoal">{c.t}</h3>
              <p className="text-[0.85rem] leading-relaxed text-muted-foreground">{c.d}</p>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">Let's make your brand feel intentional.</h2>
          <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
            <Link to="/start">Start a project</Link>
          </Button>
        </Glass>
      </Section>
    </>
  );
}
