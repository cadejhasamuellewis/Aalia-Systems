import { Link } from "react-router";
import { Check, Globe, Lock, RefreshCw, FileText, Search, Smartphone, Link2 } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { StatusPill, StatusRow, FeatureLabel } from "../../components/shared/status";
import { careIncludes, careNotIncluded } from "../../data/mock";

const checked = [
  { i: Globe, t: "Website status" },
  { i: Lock, t: "SSL certificate" },
  { i: Search, t: "Broken link notes" },
  { i: Smartphone, t: "Mobile display review" },
  { i: FileText, t: "Form submission test" },
  { i: RefreshCw, t: "Content freshness" },
];

const requestable = [
  "Text and copy changes", "Image swaps", "New announcements or banners",
  "Business hours updates", "New service or menu items", "Seasonal promotions",
];

const plans = [
  { name: "Essential", price: "Monthly from $—", desc: "Basic website checks and light updates.", features: ["Monthly website checks", "SSL + domain renewal tracking", "Up to 2 update requests / mo", "Monthly notes"], featured: false },
  { name: "Managed", price: "Monthly from $—", desc: "The organized, hands-off option most clients choose.", features: ["Everything in Essential", "Up to 4 update requests / mo", "Client platform access", "Basic analytics snapshot", "Priority support"], featured: true },
  { name: "Managed + Growth", price: "Monthly from $—", desc: "Ongoing support plus regular improvements.", features: ["Everything in Managed", "Expanded update requests", "Quarterly planning notes", "SEO basics review"], featured: false },
];

export default function Care() {
  return (
    <>
      <PageHero
        kicker="Monthly support plans"
        title="Your website should not be left alone after launch."
        support="Security-minded maintenance, basic checks, and human support — organized so your site stays current and running."
      />

      <Section>
        <SectionHeading kicker="What's included" title="What monthly support includes." />
        <div className="mt-9 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {careIncludes.map((c) => (
            <Glass key={c} className="flex items-center gap-3 p-4">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ice/70 text-aqua">
                <Check className="h-4 w-4" />
              </span>
              <span className="text-[0.9rem] leading-tight text-charcoal">{c}</span>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <div className="grid gap-4 lg:grid-cols-2">
          <Glass className="flex flex-col gap-4 p-8">
            <SectionHeading kicker="Monitoring notes" title="What gets checked." />
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              {checked.map((b) => (
                <div key={b.t} className="flex items-center gap-2.5 rounded-xl border border-white/60 bg-white/60 p-3.5">
                  <b.i className="h-4 w-4 shrink-0 text-aqua" />
                  <span className="text-[0.85rem] text-charcoal">{b.t}</span>
                </div>
              ))}
            </div>
          </Glass>
          <Glass className="flex flex-col gap-4 p-8">
            <SectionHeading kicker="Update requests" title="What clients can request." />
            <ul className="space-y-2.5">
              {requestable.map((r) => (
                <li key={r} className="flex items-center gap-2.5 text-[0.9rem] text-slate">
                  <Check className="h-4 w-4 shrink-0 text-aqua" /> {r}
                </li>
              ))}
            </ul>
          </Glass>
        </div>
      </Section>

      <Section>
        <Glass className="grid gap-8 p-8 lg:grid-cols-2 lg:p-12" tint="ice">
          <div className="flex flex-col justify-center">
            <SectionHeading
              kicker="Domain + SSL tracking"
              title="Renewals tracked so nothing lapses quietly."
              support="We keep monitoring notes on domain renewal dates and SSL status, and flag anything that needs your attention."
            />
          </div>
          <div className="grid grid-cols-2 gap-2.5">
            {[
              { i: Globe, t: "Domain renewal" },
              { i: Lock, t: "SSL status" },
              { i: Link2, t: "DNS records" },
              { i: RefreshCw, t: "Provider notes" },
            ].map((b) => (
              <div key={b.t} className="flex items-center gap-2.5 rounded-xl border border-white/60 bg-white/60 p-3.5">
                <b.i className="h-4 w-4 shrink-0 text-aqua" />
                <span className="text-[0.85rem] text-charcoal">{b.t}</span>
              </div>
            ))}
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Website update requests" title="A calm way to ask for changes." support="Submit a request through your platform — we handle approved, brand-safe edits and keep you posted." />
        <div className="mt-9 grid gap-4 md:grid-cols-3">
          {[
            { n: "01", t: "Submit your request", b: "Describe the change from your client platform." },
            { n: "02", t: "We make the edit", b: "Approved areas only — your layout and brand stay intact." },
            { n: "03", t: "You review and approve", b: "Confirm it looks right before it goes live." },
          ].map((s) => (
            <Glass key={s.n} className="flex flex-col gap-3 p-6">
              <span className="font-mono text-[1.4rem] text-copper">{s.n}</span>
              <h3 className="text-[1.05rem] text-charcoal">{s.t}</h3>
              <p className="text-[0.9rem] leading-relaxed text-muted-foreground">{s.b}</p>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading kicker="Monthly report" title="A clear snapshot each month." />
        <Glass className="mt-9 p-6 sm:p-8" tint="cream">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="text-[1.05rem] text-charcoal">Monthly report</div>
              <div className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">July 2026 · Marigold &amp; Co.</div>
            </div>
            <FeatureLabel state="Sample data" />
          </div>
          <div className="mt-5 grid gap-6 md:grid-cols-2">
            <div>
              {[
                { l: "Website status", v: "Online", tone: "ok" as const },
                { l: "SSL certificate", v: "Active", tone: "ok" as const },
                { l: "Domain renewal", v: "Mar 2027", tone: "info" as const },
                { l: "Broken links", v: "None found", tone: "ok" as const },
                { l: "Mobile review", v: "Passed", tone: "ok" as const },
                { l: "Form test", v: "Working", tone: "ok" as const },
              ].map((r) => (
                <StatusRow key={r.l} label={r.l}>
                  <StatusPill tone={r.tone}>{r.v}</StatusPill>
                </StatusRow>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              {[
                { k: "Visitors", v: "1,320" },
                { k: "Uptime", v: "99.9%" },
                { k: "Requests handled", v: "3" },
                { k: "Updates published", v: "5" },
              ].map((s) => (
                <div key={s.k} className="rounded-xl border border-white/60 bg-white/60 p-4">
                  <div className="font-mono text-[1.3rem] text-charcoal">{s.v}</div>
                  <div className="text-[0.72rem] text-muted-foreground">{s.k}</div>
                </div>
              ))}
            </div>
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Plans" title="Choose the level of care you need." align="center" className="mx-auto items-center" />
        <div className="mt-9 grid gap-4 lg:grid-cols-3">
          {plans.map((p) => (
            <Glass key={p.name} className={`flex flex-col gap-4 p-6 ${p.featured ? "ring-2 ring-aqua/40" : ""}`}>
              <div className="flex items-center justify-between">
                <h3 className="text-[1.1rem] text-charcoal">{p.name}</h3>
                {p.featured && <StatusPill tone="aqua" dot={false}>Popular</StatusPill>}
              </div>
              <div className="font-mono text-[1.1rem] text-aqua">{p.price}</div>
              <p className="text-[0.9rem] text-muted-foreground">{p.desc}</p>
              <ul className="mt-1 space-y-2">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-[0.88rem] text-slate">
                    <Check className="h-4 w-4 text-aqua" /> {f}
                  </li>
                ))}
              </ul>
              <Button asChild className="mt-auto bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/start">Start a support plan</Link>
              </Button>
            </Glass>
          ))}
        </div>
        <p className="mt-4 text-center text-[0.8rem] text-muted-foreground">Prices are placeholders. Final pricing is confirmed in your quote.</p>
      </Section>

      <Section>
        <Glass className="p-8" tint="cream">
          <SectionHeading kicker="Clear boundaries" title="What is not included." support="We're careful about what we promise. Monthly support is basic website maintenance — not a full security service." />
          <ul className="mt-6 grid gap-2.5 sm:grid-cols-2">
            {careNotIncluded.map((n) => (
              <li key={n} className="flex items-center gap-2.5 text-[0.88rem] text-muted-foreground">
                <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-muted-foreground/50" /> {n}
              </li>
            ))}
          </ul>
        </Glass>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">Keep your website organized and running, month after month.</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a support plan</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/contact">Ask a question</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
