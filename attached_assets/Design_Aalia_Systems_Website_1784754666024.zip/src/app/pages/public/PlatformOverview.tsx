import { Link } from "react-router";
import { ArrowRight } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { DashboardPreview } from "../../components/shared/DashboardPreview";
import { Icon } from "../../components/shared/icon";
import { StatusPill, FeatureLabel } from "../../components/shared/status";
import { clientProfile, platformNav } from "../../data/mock";

const features = [
  { t: "Secure client login", note: "Prototype" as const, icon: "LogIn" },
  { t: "Continue with Google", note: "Planned" as const, icon: "Chrome" },
  { t: "Dashboard overview", icon: "LayoutDashboard" },
  { t: "Website status", icon: "Globe" },
  { t: "Domain + SSL status", icon: "Server" },
  { t: "Project timeline", icon: "GitCommitHorizontal" },
  { t: "Update requests", icon: "MessageSquarePlus" },
  { t: "Support tickets", icon: "LifeBuoy" },
  { t: "Files + approvals", icon: "FolderOpen" },
  { t: "Invoices", note: "Requires payment processor setup" as const, icon: "Receipt" },
  { t: "Subscriptions", note: "Requires payment processor setup" as const, icon: "RefreshCw" },
  { t: "Maintenance reports", icon: "FileText" },
  { t: "Analytics snapshot", note: "Sample data" as const, icon: "BarChart3" },
  { t: "Tutorials", icon: "GraduationCap" },
  { t: "SEO resources", icon: "Search" },
  { t: "Brand-safe edit areas", icon: "PenSquare" },
];

export default function PlatformOverview() {
  return (
    <>
      <PageHero
        kicker="Client platform"
        title="A private workspace for your website and digital support."
        support="Clients can request updates, view project progress, track invoices, and stay organized without touching code."
      >
        <div className="flex flex-wrap gap-3">
          <Button asChild className="h-11 bg-aqua px-5 text-cream hover:bg-aqua-bright">
            <Link to="/login">View client login</Link>
          </Button>
          <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/50 px-5 text-aqua hover:bg-white">
            <Link to="/start">Start a project</Link>
          </Button>
        </div>
      </PageHero>

      <Section>
        <Glass className="overflow-hidden p-0" tint="ice">
          <div className="grid items-center gap-8 p-8 lg:grid-cols-[1fr_0.9fr] lg:p-12">
            <div className="flex flex-col justify-center">
              <SectionHeading
                kicker="At a glance"
                title="Everything in one calm, organized place."
                support="No spreadsheets, no scattered emails. Your website, requests, files, and invoices — together."
              />
            </div>
            <div className="flex justify-center lg:justify-end">
              <DashboardPreview />
            </div>
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Client dashboard preview" title="What clients see when they sign in." />
        <Glass className="mt-9 p-6 sm:p-8" tint="cream">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[
              { l: "Business", v: clientProfile.business, tone: "aqua" as const },
              { l: "Website status", v: "Online", tone: "ok" as const },
              { l: "Current plan", v: clientProfile.plan, tone: "info" as const },
              { l: "Next action", v: clientProfile.nextAction, tone: "warn" as const },
              { l: "Support status", v: clientProfile.supportStatus, tone: "ok" as const },
              { l: "Website", v: clientProfile.website, tone: "info" as const },
            ].map((c) => (
              <div key={c.l} className="rounded-xl border border-white/60 bg-white/60 p-4">
                <div className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-muted-foreground">{c.l}</div>
                <div className="mt-1.5 text-[0.95rem] text-charcoal">{c.v}</div>
                <div className="mt-2"><StatusPill tone={c.tone} dot={false}>Preview</StatusPill></div>
              </div>
            ))}
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Platform features" title="Built around how clients actually work." />
        <div className="mt-9 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((f) => (
            <Glass key={f.t} className="flex items-start gap-3 p-4">
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-ice/70 text-aqua">
                <Icon name={f.icon} className="h-4 w-4" />
              </span>
              <div className="flex flex-col gap-1.5">
                <span className="text-[0.9rem] leading-tight text-charcoal">{f.t}</span>
                {f.note && <FeatureLabel state={f.note} />}
              </div>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading kicker="Navigation" title="How the platform is organized." />
        <div className="mt-9 grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {platformNav.map((n) => (
            <div key={n.to} className="flex items-center gap-3 rounded-xl border border-white/60 bg-white/55 p-3.5 backdrop-blur-md">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-ice/70 text-aqua">
                <Icon name={n.icon} className="h-4 w-4" />
              </span>
              <span className="text-[0.88rem] text-charcoal">{n.label}</span>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">See the client platform for yourself.</h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/login">View client login <ArrowRight className="ml-1.5 h-4 w-4" /></Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/start">Start a project</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
