import { Link } from "react-router";
import { Check } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { StatusPill } from "../../components/shared/status";
import { serviceModels } from "../../data/mock";

const extraCards = [
  { id: "onetime2", name: "One-Time Website Project", price: "Starting at $—", desc: "A complete website designed, built, and handed off.", features: ["Custom design", "Defined page count", "Launch coordination"], featured: false },
  { id: "refresh", name: "Website Refresh / Redesign", price: "Starting at $—", desc: "Modernize an existing site without a full rebuild.", features: ["Visual refresh", "Content restructure", "Mobile improvements"], featured: false },
  { id: "managed", name: "Managed Website + Client Platform", price: "Monthly from $—", desc: "Build plus ongoing care and platform access.", features: ["Website + care", "Client platform", "Update requests"], featured: true },
  { id: "contractor", name: "Contractor / Fractional Support", price: "Custom quote", desc: "Ongoing design + systems support for teams.", features: ["Retained hours", "Priority requests", "Systems planning"], featured: false },
];

const allCards = [...serviceModels, ...extraCards];

const addons = [
  "Branding kit", "Fillable forms", "Document templates", "E-commerce setup",
  "POS coordination", "Extra pages", "Extra update requests", "SEO setup",
  "Domain / hosting coordination",
];

export default function Pricing() {
  return (
    <>
      <PageHero
        kicker="Pricing"
        title="Simple service models, quoted to fit."
        support="Choose how you'd like to work together. Every project is confirmed with a written quote — the figures below are placeholders."
      />

      <Section>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {allCards.map((m) => (
            <Glass key={m.id} className={`flex flex-col gap-4 p-6 ${m.featured ? "ring-2 ring-aqua/40" : ""}`}>
              <div className="flex items-center justify-between gap-2">
                <h3 className="text-[1.05rem] leading-tight text-charcoal">{m.name}</h3>
                {m.featured && <StatusPill tone="aqua" dot={false}>Popular</StatusPill>}
              </div>
              <div className="font-mono text-[1.1rem] text-aqua">{m.price}</div>
              <p className="text-[0.88rem] text-muted-foreground">{m.desc}</p>
              <ul className="mt-1 space-y-2">
                {m.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-[0.86rem] text-slate">
                    <Check className="h-4 w-4 text-aqua" /> {f}
                  </li>
                ))}
              </ul>
              <Button asChild className="mt-auto bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/start">Request a quote</Link>
              </Button>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <Glass className="p-8 lg:p-12" tint="ice">
          <SectionHeading kicker="Add-ons" title="Extend any project." support="Mix and match to build exactly what your business needs." />
          <div className="mt-7 flex flex-wrap gap-2.5">
            {addons.map((a) => (
              <span key={a} className="inline-flex items-center gap-2 rounded-full border border-white/60 bg-white/60 px-4 py-2 text-[0.85rem] text-charcoal backdrop-blur-md">
                <Check className="h-3.5 w-3.5 text-aqua" /> {a}
              </span>
            ))}
          </div>
        </Glass>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-5 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">Every project gets a clear, written quote.</h2>
          <p className="max-w-lg text-[0.9rem] text-muted-foreground">
            All prices shown are placeholders. Your final pricing depends on scope,
            and is confirmed before any work begins.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a project</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/contact">Ask about pricing</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
