import { Link } from "react-router";
import { Check, Globe, ShieldCheck, FileText, Palette, Server, CheckSquare, ShoppingBag, Monitor } from "lucide-react";
import { Button } from "../../components/ui/button";
import { Glass, Chip } from "../../components/shared/glass";
import { Section, SectionHeading } from "../../components/shared/section";
import { PageHero } from "../../components/shared/PageHero";
import { StatusPill } from "../../components/shared/status";

function StatusRow({ label, value, ok = true }: { label: string; value: string; ok?: boolean }) {
  return (
    <div className="flex items-center justify-between rounded-md bg-white/50 px-3 py-2 text-[0.8rem]">
      <span className="text-slate">{label}</span>
      <span className={`font-mono ${ok ? "text-aqua" : "text-copper"}`}>{value}</span>
    </div>
  );
}

function CheckItem({ label, ok = true }: { label: string; ok?: boolean }) {
  return (
    <div className="flex items-center gap-2 text-[0.82rem]">
      <div className={`h-2 w-2 shrink-0 rounded-full ${ok ? "bg-aqua" : "bg-muted-foreground"}`} />
      <span className="text-slate">{label}</span>
    </div>
  );
}

export default function WorkSystems() {
  return (
    <>
      <PageHero
        kicker="Work + Systems"
        title="Real workflows. Real service examples."
        support="System-style examples of how Aalia organizes and manages digital business operations — not generic stock website cards."
      />

      <Section>
        <SectionHeading
          kicker="Coded website"
          title="Custom coded website"
          support="Real project currently in development."
        />
        <Glass className="mt-8 overflow-hidden p-0">
          <div className="grid gap-0 lg:grid-cols-2">
            {/* Mini website preview */}
            <div className="border-b border-white/40 p-8 lg:border-b-0 lg:border-r">
              <div className="rounded-xl border border-white/60 bg-white/70 shadow-sm overflow-hidden">
                {/* Fake browser chrome */}
                <div className="flex items-center gap-1.5 border-b border-white/60 bg-white/40 px-3 py-2">
                  <div className="h-2 w-2 rounded-full bg-blush/70" />
                  <div className="h-2 w-2 rounded-full bg-copper/40" />
                  <div className="h-2 w-2 rounded-full bg-aqua/40" />
                  <div className="ml-2 flex-1 rounded bg-white/60 px-3 py-0.5 font-mono text-[0.6rem] text-muted-foreground">beautyandserenity.com</div>
                </div>
                {/* Fake page content */}
                <div className="bg-gradient-to-br from-[#f9f5f0] to-[#e8f0f1] p-5">
                  <div className="font-display text-[1.1rem] text-charcoal">Beauty &amp; Serenity</div>
                  <div className="font-mono text-[0.6rem] uppercase tracking-widest text-copper">Hair Restoration Center</div>
                  <div className="mt-3 space-y-1.5">
                    {["Services", "About", "Gallery", "Contact"].map((p) => (
                      <div key={p} className="h-2 w-24 rounded-full bg-aqua/20" />
                    ))}
                  </div>
                  <div className="mt-4 flex gap-2">
                    <div className="rounded-md bg-aqua px-3 py-1.5 font-mono text-[0.6rem] text-cream">Book a consultation</div>
                    <div className="rounded-md border border-aqua/30 px-3 py-1.5 font-mono text-[0.6rem] text-aqua">View services</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col justify-center gap-4 p-8">
              <StatusPill tone="info" dot>Real project · In development</StatusPill>
              <h3 className="text-[1.1rem] text-charcoal">Beauty &amp; Serenity Hair Restoration Center</h3>
              <p className="text-[0.9rem] leading-relaxed text-muted-foreground">
                A custom coded website built around the client&apos;s brand, service structure, and inquiry flow.
                Healthcare-adjacent wording is boundary-safe. No PHI stored on the website.
              </p>
              <div className="space-y-1.5">
                <CheckItem label="Custom coded — not a template" />
                <CheckItem label="Service pages and contact/inquiry flow" />
                <CheckItem label="Brand direction and visual system" />
                <CheckItem label="PHI stays in client-controlled EHR" />
                <CheckItem label="Mobile-first responsive layout" />
              </div>
              <Button asChild className="mt-2 w-fit bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/start">Start a similar project</Link>
              </Button>
            </div>
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Managed subscription" title="Monthly managed support" support="Concept demonstration — sample data." />
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <Glass className="flex flex-col gap-4 p-6">
            <div className="flex items-center gap-3">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-aqua/10 text-aqua"><ShieldCheck className="h-4 w-4" /></span>
              <div>
                <div className="text-[0.95rem] text-charcoal">Website status dashboard</div>
                <StatusPill tone="aqua" dot={false} className="mt-0.5">Sample data</StatusPill>
              </div>
            </div>
            <div className="space-y-1.5">
              <StatusRow label="Website" value="Online" />
              <StatusRow label="Domain" value="Connected" />
              <StatusRow label="SSL" value="Active" />
              <StatusRow label="Monthly support" value="Active" />
              <StatusRow label="Last checked" value="Jul 21, 2026" />
            </div>
          </Glass>
          <Glass className="flex flex-col gap-4 p-6">
            <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper">Monthly report · Jul 2026</div>
            <div className="space-y-2">
              {[
                { label: "SSL check", ok: true },
                { label: "Broken link check", ok: true },
                { label: "Form test", ok: true },
                { label: "Mobile review", ok: true },
                { label: "Update requests processed", ok: true },
                { label: "Analytics snapshot attached", ok: true },
              ].map((i) => <CheckItem key={i.label} label={i.label} ok={i.ok} />)}
            </div>
            <div className="mt-2 rounded-lg border border-white/60 bg-white/50 p-3">
              <div className="font-mono text-[0.65rem] uppercase tracking-wide text-muted-foreground">Update requests this month</div>
              <div className="mt-1.5 space-y-1">
                {["Add August promo banner · Approved", "Update team photo · In progress"].map((r) => (
                  <div key={r} className="text-[0.8rem] text-slate">{r}</div>
                ))}
              </div>
            </div>
            <p className="mt-auto font-mono text-[0.64rem] text-muted-foreground">Security-minded maintenance · not a cybersecurity service</p>
          </Glass>
        </div>
      </Section>

      <Section>
        <SectionHeading kicker="POS + systems" title="POS + business systems setup" support="Setup coordination and workflow support. Not financial, accounting, or tax advice." />
        <Glass className="mt-8 p-0 overflow-hidden">
          <div className="grid gap-0 lg:grid-cols-3">
            <div className="border-b border-white/40 p-6 lg:border-b-0 lg:border-r">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Setup checklist</div>
              <div className="space-y-2">
                {["POS hardware coordination", "Product/service list setup", "Staff workflow guide", "Receipt / printing config", "Vendor support coordination", "Training documentation"].map((i) => (
                  <div key={i} className="flex items-center gap-2 text-[0.82rem] text-slate">
                    <Check className="h-3.5 w-3.5 shrink-0 text-aqua" />{i}
                  </div>
                ))}
              </div>
            </div>
            <div className="border-b border-white/40 p-6 lg:border-b-0 lg:border-r">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Service menu organization</div>
              <div className="space-y-1.5">
                {[["Cut + Style", "$85"], ["Color Service", "$120+"], ["Treatment", "$65"], ["Blowout", "$55"]].map(([n, p]) => (
                  <div key={n} className="flex items-center justify-between rounded-md bg-white/50 px-3 py-2 text-[0.8rem]">
                    <span className="text-slate">{n}</span>
                    <span className="font-mono text-aqua">{p}</span>
                  </div>
                ))}
              </div>
              <div className="mt-3 font-mono text-[0.62rem] text-muted-foreground">Sample data · Concept demo</div>
            </div>
            <div className="p-6">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Website / POS coordination</div>
              <p className="text-[0.82rem] leading-relaxed text-muted-foreground">
                When your website and POS system show the same service list, hours, and pricing — clients get a consistent experience and you spend less time correcting mismatches.
              </p>
              <div className="mt-4 rounded-lg border border-copper/20 bg-copper/5 p-3">
                <div className="font-mono text-[0.65rem] uppercase tracking-wide text-copper">Note</div>
                <div className="mt-1 text-[0.8rem] text-slate">POS support is setup coordination only. Aalia does not provide financial, accounting, or tax advice.</div>
              </div>
            </div>
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Documents + forms" title="Business documents and fillable forms" support="Concept demonstration." />
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { title: "Client intake form", type: "Fillable PDF", fields: ["Business name", "Services needed", "Budget range", "Timeline"] },
            { title: "Service agreement", type: "Document template", fields: ["Scope of work", "Payment terms", "Revision policy", "Signatures"] },
            { title: "Staff checklist", type: "Operational doc", fields: ["Opening tasks", "Closing tasks", "Daily review", "Notes field"] },
          ].map((doc) => (
            <Glass key={doc.title} className="flex flex-col gap-4 p-5">
              <div className="flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-copper/10 text-copper"><FileText className="h-4 w-4" /></span>
                <div>
                  <div className="text-[0.9rem] text-charcoal">{doc.title}</div>
                  <div className="font-mono text-[0.62rem] text-muted-foreground">{doc.type}</div>
                </div>
              </div>
              {/* Mini form preview */}
              <div className="space-y-1.5">
                {doc.fields.map((f) => (
                  <div key={f} className="rounded border border-white/60 bg-white/40 px-2.5 py-1.5">
                    <div className="font-mono text-[0.58rem] uppercase tracking-wide text-muted-foreground">{f}</div>
                    <div className="mt-0.5 h-1.5 w-3/4 rounded-full bg-slate/10" />
                  </div>
                ))}
              </div>
              <StatusPill tone="warn" dot={false}>Concept demo · Sample data</StatusPill>
            </Glass>
          ))}
        </div>
      </Section>

      <Section>
        <SectionHeading kicker="Brand identity" title="Brand revamp and visual identity" support="Concept demonstration — not a completed client project." />
        <Glass className="mt-8 p-0 overflow-hidden">
          <div className="grid gap-0 lg:grid-cols-2">
            <div className="border-b border-white/40 p-8 lg:border-b-0 lg:border-r">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-4">Color palette</div>
              <div className="flex flex-wrap gap-3">
                {[
                  { hex: "#16565C", name: "Deep aqua" },
                  { hex: "#7E5A3B", name: "Warm copper" },
                  { hex: "#F5F0E8", name: "Pearl cream" },
                  { hex: "#B8D4D8", name: "Ice blue" },
                  { hex: "#2C3340", name: "Charcoal" },
                ].map((c) => (
                  <div key={c.hex} className="flex flex-col items-center gap-1.5">
                    <div className="h-12 w-12 rounded-xl border border-white/60 shadow-sm" style={{ background: c.hex }} />
                    <div className="font-mono text-[0.6rem] text-muted-foreground">{c.name}</div>
                  </div>
                ))}
              </div>
              <div className="mt-6 font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Typography</div>
              <div className="space-y-1.5">
                <div className="font-display text-[1.5rem] leading-none text-charcoal">Display — Fraunces</div>
                <div className="font-sans text-[0.9rem] text-slate">Body — Figtree · clean and readable</div>
                <div className="font-mono text-[0.75rem] uppercase tracking-widest text-copper">Mono — JetBrains Mono</div>
              </div>
            </div>
            <div className="flex flex-col gap-4 p-8">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper">Brand deliverables</div>
              <div className="space-y-2">
                {["Logo direction", "Color palette guide", "Typography system", "Social media templates", "Business card layout", "Email signature", "Website section redesign", "Before / after concept"].map((d) => (
                  <div key={d} className="flex items-center gap-2 text-[0.85rem] text-slate">
                    <Check className="h-3.5 w-3.5 shrink-0 text-aqua" />{d}
                  </div>
                ))}
              </div>
              <Button asChild className="mt-4 w-fit bg-aqua text-cream hover:bg-aqua-bright">
                <Link to="/start">Start a brand project</Link>
              </Button>
            </div>
          </div>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="E-commerce" title="E-commerce setup" support="Setup and support on established platforms. Concept demonstration — sample data." />
        <Glass className="mt-8 p-6">
          <div className="grid gap-6 md:grid-cols-2">
            <div>
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Product catalog structure</div>
              <div className="space-y-1.5">
                {[["All products", "24 items"], ["Featured", "6 items"], ["New arrivals", "4 items"], ["Sale", "8 items"]].map(([cat, count]) => (
                  <div key={cat} className="flex items-center justify-between rounded-md bg-white/50 px-3 py-2 text-[0.82rem]">
                    <span className="text-slate">{cat}</span>
                    <span className="font-mono text-muted-foreground">{count}</span>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Setup coordination includes</div>
              <div className="space-y-1.5">
                {["Product catalog setup", "Collection / category structure", "Homepage promo area", "Store policies", "Product image guidance", "Payment platform coordination"].map((i) => (
                  <div key={i} className="flex items-center gap-2 text-[0.82rem] text-slate">
                    <Check className="h-3.5 w-3.5 shrink-0 text-aqua" />{i}
                  </div>
                ))}
              </div>
              <div className="mt-3 rounded-lg border border-aqua/20 bg-aqua/5 p-3 text-[0.8rem] text-slate">
                Payments handled through Square or established platform. Aalia does not store card data.
              </div>
            </div>
          </div>
          <StatusPill tone="aqua" dot={false} className="mt-4">Sample data · Concept demonstration</StatusPill>
        </Glass>
      </Section>

      <Section>
        <SectionHeading kicker="Domain + hosting" title="Domain and hosting coordination" support="Concept demonstration — sample data." />
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <Glass className="flex flex-col gap-3 p-6">
            <div className="flex items-center gap-3 mb-1">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-aqua/10 text-aqua"><Server className="h-4 w-4" /></span>
              <div className="text-[0.95rem] text-charcoal">Domain status</div>
            </div>
            <div className="space-y-1.5">
              <StatusRow label="Domain provider" value="Namecheap" />
              <StatusRow label="Domain" value="yourbusiness.com" />
              <StatusRow label="Renewal date" value="Mar 2, 2027" />
              <StatusRow label="DNS status" value="Configured" />
              <StatusRow label="SSL" value="Auto-renew on" />
              <StatusRow label="Hosting provider" value="Managed host" />
              <StatusRow label="Email provider" value="Google Workspace" />
            </div>
            <StatusPill tone="aqua" dot={false} className="mt-1">Sample data</StatusPill>
          </Glass>
          <Glass className="flex flex-col gap-4 p-6">
            <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper">What coordination includes</div>
            <div className="space-y-1.5">
              {["Domain provider setup support", "DNS record configuration", "SSL setup and renewal tracking", "Hosting provider coordination", "Renewal reminder schedule", "Email provider coordination", "Notes and records kept in client platform"].map((i) => (
                <div key={i} className="flex items-center gap-2 text-[0.82rem] text-slate">
                  <Check className="h-3.5 w-3.5 shrink-0 text-aqua" />{i}
                </div>
              ))}
            </div>
            <div className="mt-auto rounded-lg border border-aqua/20 bg-aqua/5 p-3 text-[0.79rem] text-slate">
              Aalia coordinates on your behalf. Credentials and control stay with you or your approved provider.
            </div>
          </Glass>
        </div>
      </Section>

      <Section>
        <SectionHeading kicker="Maintenance" title="Security-minded website maintenance" support="Monthly checks and maintenance notes. Not a cybersecurity service — no formal security certification." />
        <Glass className="mt-8 p-0 overflow-hidden">
          <div className="grid gap-0 lg:grid-cols-3">
            <div className="border-b border-white/40 p-6 lg:border-b-0 lg:border-r">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Monthly check · Jul 2026</div>
              <div className="space-y-2">
                {[["SSL check", true], ["Broken link notes", true], ["Form test", true], ["Mobile review", true], ["Basic performance check", true], ["Backup note", true]].map(([l, ok]) => (
                  <div key={String(l)} className="flex items-center justify-between rounded-md bg-white/50 px-3 py-2 text-[0.8rem]">
                    <span className="text-slate">{String(l)}</span>
                    <div className={`h-2 w-2 rounded-full ${ok ? "bg-aqua" : "bg-copper"}`} />
                  </div>
                ))}
              </div>
            </div>
            <div className="border-b border-white/40 p-6 lg:border-b-0 lg:border-r">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Maintenance notes</div>
              <div className="space-y-2 text-[0.82rem] text-slate">
                <div className="rounded-md bg-white/50 p-3">No broken links detected this month.</div>
                <div className="rounded-md bg-white/50 p-3">Contact form tested — sending correctly.</div>
                <div className="rounded-md bg-white/50 p-3">Mobile layout reviewed on 3 device sizes.</div>
                <div className="rounded-md bg-white/50 p-3">SSL auto-renewal confirmed through host.</div>
              </div>
              <StatusPill tone="aqua" dot={false} className="mt-3">Sample data</StatusPill>
            </div>
            <div className="p-6">
              <div className="font-mono text-[0.65rem] uppercase tracking-[0.14em] text-copper mb-3">Language note</div>
              <div className="space-y-2.5 text-[0.82rem] text-slate">
                <p>Aalia performs security-minded website maintenance — not a formal cybersecurity service.</p>
                <p>Checks include basic website health review, link verification, SSL status, and mobile testing.</p>
                <p>No guaranteed security protection. No formal certification claimed.</p>
              </div>
            </div>
          </div>
        </Glass>
      </Section>

      <Section>
        <Glass className="flex flex-col items-center gap-6 p-10 text-center sm:p-16" tint="aqua">
          <h2 className="max-w-xl text-[2rem] leading-tight text-charcoal">
            Ready to start a project or move into managed care?
          </h2>
          <div className="flex flex-wrap justify-center gap-3">
            <Button asChild className="h-11 bg-aqua px-6 text-cream hover:bg-aqua-bright">
              <Link to="/start">Start a project</Link>
            </Button>
            <Button asChild variant="outline" className="h-11 border-aqua/30 bg-white/60 px-6 text-aqua hover:bg-white">
              <Link to="/care">Monthly support plans</Link>
            </Button>
          </div>
        </Glass>
      </Section>
    </>
  );
}
