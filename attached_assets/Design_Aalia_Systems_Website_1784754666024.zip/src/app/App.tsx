import { BrowserRouter, Routes, Route } from "react-router";
import { Toaster } from "./components/ui/sonner";
import PublicLayout from "./components/layout/PublicLayout";
import PlatformLayout from "./components/layout/PlatformLayout";

// Public pages
import Home from "./pages/public/Home";
import Services from "./pages/public/Services";
import Care from "./pages/public/Care";
import PlatformOverview from "./pages/public/PlatformOverview";
import WorkSystems from "./pages/public/WorkSystems";
import Branding from "./pages/public/Branding";
import Pos from "./pages/public/Pos";
import Pricing from "./pages/public/Pricing";
import Start from "./pages/public/Start";
import Contact from "./pages/public/Contact";
import About from "./pages/public/About";
import Privacy from "./pages/public/Privacy";
import Terms from "./pages/public/Terms";
import Login from "./pages/public/Login";

// Client platform pages
import Overview from "./pages/platform/Overview";
import Website from "./pages/platform/Website";
import Domain from "./pages/platform/Domain";
import Requests from "./pages/platform/Requests";
import BrandSafeEdit from "./pages/platform/BrandSafeEdit";
import Files from "./pages/platform/Files";
import Invoices from "./pages/platform/Invoices";
import Subscriptions from "./pages/platform/Subscriptions";
import Analytics from "./pages/platform/Analytics";
import Tutorials from "./pages/platform/Tutorials";
import Seo from "./pages/platform/Seo";
import Tickets from "./pages/platform/Tickets";
import Settings from "./pages/platform/Settings";

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<PublicLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/care" element={<Care />} />
          <Route path="/platform-overview" element={<PlatformOverview />} />
          <Route path="/work-systems" element={<WorkSystems />} />
          <Route path="/branding" element={<Branding />} />
          <Route path="/pos" element={<Pos />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/start" element={<Start />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/about" element={<About />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
        </Route>

        <Route path="/login" element={<Login />} />

        <Route path="/platform" element={<PlatformLayout />}>
          <Route index element={<Overview />} />
          <Route path="website" element={<Website />} />
          <Route path="domain" element={<Domain />} />
          <Route path="requests" element={<Requests />} />
          <Route path="edit" element={<BrandSafeEdit />} />
          <Route path="files" element={<Files />} />
          <Route path="invoices" element={<Invoices />} />
          <Route path="subscriptions" element={<Subscriptions />} />
          <Route path="analytics" element={<Analytics />} />
          <Route path="tutorials" element={<Tutorials />} />
          <Route path="seo" element={<Seo />} />
          <Route path="tickets" element={<Tickets />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
      <Toaster position="top-center" />
    </BrowserRouter>
  );
}
